package application;

import java.util.ArrayList;
import com.milgra.server.Client;
import com.milgra.server.Wrapper;
import com.milgra.server.IApplication;


public class Application implements IApplication
{

	public Application ( ) 
	{ 
		System.out.println( System.currentTimeMillis() + " MilGraDemoStream started" ); 
	}
	
	public void onEnter ( Client clientX , ArrayList < Wrapper > argumentsX ) 
	{ 
		System.out.println( System.currentTimeMillis() + " MilGraDemoStream.onEnter " + clientX.id + " " + clientX.ip ); 
		new UserController( clientX ); 
	}
	
	public void onLeave ( Client clientX ) 
	{
		System.out.println( System.currentTimeMillis() + " MilGraDemoStream.onLeave " + clientX.id + " " + clientX.ip ); 		
	}
	
	public void onClose ( ) 
	{
		System.out.println( System.currentTimeMillis() + " MilGraDemoStream.onClose" ); 				
	}

}
