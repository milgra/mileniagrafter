package application;

import java.util.HashMap;

import com.milgra.server.Client;
import com.milgra.server.Wrapper;
import com.milgra.server.EventListener;

public class UserController 
{
	
	public Client client;
	
	/**
	 * UserController constructor
	 * @param clientX
	 */
	
	public UserController ( Client clientX )
	{
		
		System.out.println( System.currentTimeMillis() + " UserController.construct " + clientX.ip + " " + clientX.id );
		
		// creating invoke event listener
		
		EventListener invokeEL = new EventListener ( )
		{
			public void onEvent ( HashMap < String , Wrapper > eventX ) { onInvoke( eventX ); }
		};
		
		// store client
		
		client = clientX;
		
		// add listener
		
		client.addInvokeEventListener( invokeEL );
		
		// accepting client with empty response object
		
		client.accept( new Wrapper( ) );
		
	}
	
	/**
	 * Incoming invokes
	 * @param eventX
	 */
	
	public void onInvoke ( HashMap < String , Wrapper > eventX )
	{
		
		// get invoke id
		
		String invokeID = eventX.get( "invokeid" ).stringValue;

		System.out.println( System.currentTimeMillis() + " USerController.onInvoke: " + invokeID );

		if ( invokeID.equals( "addStreamEventListener" ) ) addStreamEventListener( );
		if ( invokeID.equals( "recordValidStream" ) ) recordValidStream( );	
		if ( invokeID.equals( "removeNormalStream" ) ) removeNormalStream( );
		
	}
	
	/**
	 * Incoming stream events
	 * @param eventX
	 */
	
	public void onStreamEvent ( HashMap < String , Wrapper > eventX )
	{
		
		String eventid = eventX.get( "eventid" ).stringValue;
		String name = eventX.get( "streamname" ).stringValue;
		double id = eventX.get( "streamid" ).doubleValue;
		
		System.out.println( System.currentTimeMillis() + " UserController.onStreamEvent " + eventid + " " + id + " " + name  );
		
		if ( eventid.equals( "publish" ) )
		{

			String mode = eventX.get( "streammode" ).stringValue;
			
			if ( name.equals( "invalidstream" ) ) 
			{
				
				// disable publishing invalidstream
				
				System.out.println( "Disable publishing invalidstream" );
				client.disableStreamPublish( id , name );
				
			}
			if ( name.equals( "validstream" ) ) 
			{
				
				// enable publishing
				
				System.out.println( "Enable publishing validstream" );
				client.enableStreamPublish( id , name , mode );
				
			}
			
		}
		
		if ( eventid.equals( "play" ) ) 
		{
			// disable playing invalidstream
			if ( name.equals( "invalidstream" ) ) 
			{
				System.out.println( "Disable playing invalidstream" );
				client.disableStreamPlay( id , name );
			}
			
			// enable playing  validstream
			if ( name.equals( "validstream" ) ) 
			{
				System.out.println( "Enable playing invalidstream" );
				client.enableStreamPlay( id , name );
			}
		}
	}
	
	/**
	 * Adding a stream event listener
	 */
	
	public void addStreamEventListener ( )
	{
		
		System.out.println( System.currentTimeMillis() + " UserController.addstreamEventListener " );
		
		// creating stream event listener
		
		EventListener streamEL = new EventListener ( )
		{
			public void onEvent( HashMap < String , Wrapper > eventX ) { onStreamEvent( eventX ); }
		};
		
		// adding event listener
		
		client.addStreamEventListener( streamEL );
		
	}
	
	/**
	 * Records "validstream"
	 */
	
	public void recordValidStream ( )
	{
		
		System.out.println( System.currentTimeMillis() + " UserController.recordValidStream" );

		HashMap < Double , String > published = client.getPublishedStreams( );
		
		// searching for valid stream's id
		
		for ( double id : published.keySet( ) )
		{

			if ( published.get( id ).equals( "validstream" ) )
			{
				
				System.out.println( "Recording validstream" );

				// record valid stream

				client.recordStream( id , true );
		
			}
		}
				
	}
	
	/**
	 * Removes "normalstream"
	 */
	
	public void removeNormalStream ( )
	{
		
		System.out.println( System.currentTimeMillis() + " UserController.removeNormalStream" );

		HashMap < Double , String > published = client.getPublishedStreams( );
		
		// searching for normalstream's id
		
		for ( double id : published.keySet( ) )
		{
			
			
			if ( published.get( id ).equals( "normalstream" ) )
			{
				
				System.out.println( "Deleting normalstream" );

				// delete valid stream
				
				client.deleteStream( id );
				
			}
			
		}
		
	}

}
