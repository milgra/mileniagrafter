package application;

import java.util.HashMap;
import java.util.ArrayList;

import com.milgra.server.Client;
import com.milgra.server.Wrapper;
import com.milgra.server.IApplication;

public class Application implements IApplication
{
	
	public HashMap < Long , UserController > users;
	
	public Application ( )
	{	
		
		System.out.println( System.currentTimeMillis() + " MilGraTutorial started" );
		
		users = new HashMap < Long , UserController > ( );
		
	}
	
	public void onEnter ( Client clientX , ArrayList < Wrapper > argumentsX )
	{
		
		System.out.println( System.currentTimeMillis() + " MilGraTutorial.onEnter " + clientX.id + " " + clientX.ip );
		
		users.put( clientX.id , new UserController( clientX ) );
		
	}
	
	public void onLeave ( Client clientX )
	{
		
		System.out.println( System.currentTimeMillis() + " MilGraTutorial.onEnter " + clientX.id + " " + clientX.ip );
		
		users.remove( clientX.id );
		
	}
	
	public void onClose ( )	
	{
		
		System.out.println( System.currentTimeMillis() + " MilGraTutorial.onClose" );
		
		users = null;
		
	}
	
}
