package application;

import java.util.HashMap;
import com.milgra.server.Client;
import com.milgra.server.Wrapper;
import com.milgra.server.EventListener;


public class UserController 
{
	
	public Client client;
	
	
	public UserController ( Client clientX )
	{
		
		System.out.println( System.currentTimeMillis() + " UserController.construct " + clientX.id );
		
		// create stream event listener
		
		EventListener streamEL = new EventListener ( )
		{			
			public void onEvent ( HashMap < String , Wrapper > eventX ) { onStream( eventX ); }	
		};
		
		// store client

		client = clientX;
		
		// add event listener
		
		client.addStreamEventListener( streamEL );
		
		// accept client
		
		client.accept( new Wrapper( client.id ) );
		
	}
	
	/**
	 * Stream event
	 * @param eventX
	 */
	
	public void onStream ( HashMap < String , Wrapper > eventX )
	{		
		
		String eventID = eventX.get( "eventid" ).stringValue;
		double streamID = eventX.get( "streamid" ).doubleValue;
		String streamName = eventX.get( "streamname" ).stringValue;
		String streamMode = eventX.get( "streammode" ).stringValue;
		
		System.out.println( System.currentTimeMillis() + " UserController.onStream " + client.id + " " + eventID + " " + streamID + " " + streamName );
		
		// if stream name is ok, enable publish
		
		if ( streamName.equals( "stream" + client.id ) )
		{
			System.out.println( "enable publish " + streamName );
			client.enableStreamPublish( streamID , streamName , streamMode );
		}
		
		// if not ok, disable
		
		else
		{
			System.out.println( "disable publish " + streamName );
			client.disableStreamPublish( streamID , streamName );
		}
	}

}
