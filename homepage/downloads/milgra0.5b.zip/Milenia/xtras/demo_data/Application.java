package application;

import java.util.HashMap;
import java.util.ArrayList;

import com.milgra.server.Client;
import com.milgra.server.Wrapper;
import com.milgra.server.IApplication;
import com.milgra.server.EventListener;


public class Application implements IApplication
{
	
	public HashMap < Long , Client > clients;
	
	/**
	 * MilGraDemoData constructor
	 */
	
	public Application ( )
	{
		
		System.out.println( System.currentTimeMillis() + " MilGraDemoData started" );
		
		// client containers
		clients = new HashMap < Long , Client > ( );
		
	}
	
	/**
	 * Closing, cleanup
	 */
	
	public void onClose ( ) 
	{
		
		System.out.println( System.currentTimeMillis() + " MilGraDemoData.onClose" );
		
		// set container to null for garbage collection
		clients = null;
		
	} 
	
	/**
	 * Client entering point
	 */
	
	public void onEnter ( Client clientX , ArrayList < Wrapper > arguments ) 
	{
		
		System.out.println( System.currentTimeMillis() + " MilGraDemoData.onEnter: " + clientX.ip );
		
		// define invoke event listener
		
		EventListener invokeEL = new EventListener ( )
		{
			public void onEvent ( HashMap < String , Wrapper > eventX ) { onInvoke( eventX ); }
		};
		
		// add event listener
		
		clientX.addInvokeEventListener( invokeEL );
		
		// store client
		
		clients.put( clientX.id , clientX );
		
		// accept client
		
		clientX.accept( new Wrapper( ) );
		
	}
	
	/**
	 * Client leaving point
	 */
	
	public void onLeave ( Client clientX ) 
	{
		
		System.out.println( System.currentTimeMillis() + " MilGraDemoData.onLeave " + clientX.ip );
		
		clients.remove( clientX.id );
		
	}
	
	/**
	 * Incoming invokes
	 * @param eventX invoke event
	 */
	
	public void onInvoke ( HashMap < String , Wrapper > eventX )
	{
		
		// getting client
		
		long clientID = eventX.get( "clientid" ).longValue;
		Client client = clients.get( clientID );
		
		// getting invoke id and arguments
		
		String invokeID = eventX.get( "invokeid" ).stringValue;
		ArrayList < Wrapper > arguments = eventX.get( "arguments" ).listValue;
		
		// receiveing null value
		
		if ( invokeID.equals( "receiveNull" ) ) 
			System.out.println( System.currentTimeMillis() + " receiveNull: " + arguments.get( 0 ).type + " " + arguments.get( 0 ).value );
		
		// receiving boolean value
		
		if ( invokeID.equals( "receiveBoolean" ) )
			System.out.println( System.currentTimeMillis() + " receiveBoolean: " + arguments.get( 0 ).type + " " + arguments.get( 0 ).value );
		
		// receiveing integer ( AMF 1 has only one kind of number type : double, so itwill be double )
		
		if ( invokeID.equals( "receiveInteger" ) )
			System.out.println( System.currentTimeMillis() + " receiveInteger " + arguments.get( 0 ).type + " " + arguments.get( 0 ).value );
		
		// receiving number ( as double )
		
		if ( invokeID.equals( "receiveNumber" ) )
			System.out.println( System.currentTimeMillis() + " receiveNumber: " + arguments.get( 0 ).type + " " + arguments.get( 0 ).value );
		
		// receiving string value
		
		if ( invokeID.equals( "receiveString" ) )
			System.out.println( System.currentTimeMillis() + " receiveString: " + arguments.get( 0 ).type + " " + arguments.get( 0 ).value );
		
		// receiving array value
		
		if ( invokeID.equals( "receiveArray" ) )
		{
			System.out.println( System.currentTimeMillis() + " receiveArray: " + arguments.get( 0 ).type );
			ArrayList < Wrapper > array = arguments.get( 0 ).listValue;
			
			// looping through values
			
			for ( int a = 0 ; a < array.size() ; a++ ) System.out.println( a + " : " + array.get( a ).value );
			
		}
		
		// receiving object
		
		if ( invokeID.equals( "receiveObject" ) )
		{
			System.out.println( System.currentTimeMillis() + " receiveObject: " + arguments.get( 0 ).type );
			
			HashMap < String , Wrapper > map = arguments.get( 0 ).hashValue;
			
			// get values
			
			String key = map.get( "key" ).stringValue;
			Double num = map.get( "num" ).doubleValue;
			ArrayList < Wrapper > array = map.get( "array" ).listValue;
			
			System.out.println( "key: " + key );
			System.out.println( "num: " + num );
			System.out.println( "array: " );
			
			// looping through array
			
			for ( int a = 0 ; a < array.size() ; a++ ) System.out.println( a + " : " + array.get( a ).value );
			
		}
		
		// receiving callback
		
		if ( invokeID.equals( "callBack" ) )
		{
			
			System.out.println( System.currentTimeMillis() + " callBack: " + arguments.get( 0 ).type + " " + arguments.get( 0 ).value );
			
			// passing back result
			
			client.callResult( "callBack" , arguments );
			
			// invoke server side value send
			
			sendValues( client );

		}
	
	}
	
	/**
	 * Outgoing invokes
	 * @param clientX Client
	 */
	
	public void sendValues ( Client clientX )
	{
		
		System.out.println( System.currentTimeMillis() + " sendValues " );
		
		// defining values
			
		boolean booleanValue = true;
		int integerValue = 456;
		double numberValue = 32342352135.23523;
		String stringValue = "Milenia Grafter Client";
		
		ArrayList < Wrapper > arrayValue = new ArrayList < Wrapper > ( );
		
		arrayValue.add( new Wrapper ( "dslakfja;iewehd" ) );
		arrayValue.add( new Wrapper ( 53245245 ) );
		arrayValue.add( new Wrapper ( 23233412.32546256 ) );
		arrayValue.add( new Wrapper ( ) );
		arrayValue.add( new Wrapper ( false ) );
		
		HashMap < String , Wrapper > objectValue = new HashMap < String , Wrapper > ( );
		
		objectValue.put( "key" , new Wrapper( "milgra" ) );
		objectValue.put( "num" , new Wrapper( 43456423 ) );
		objectValue.put( "array" , new Wrapper( arrayValue ) );
		
		// send null
		
		System.out.println( System.currentTimeMillis() + " sendNull" );
		clientX.call( "receiveNull" , new Wrapper( ) );
		
		// send boolean
		
		System.out.println( System.currentTimeMillis() + " sendBoolean" );
		clientX.call( "receiveBoolean" , new Wrapper( booleanValue ) );
		
		// send integer
		
		System.out.println( System.currentTimeMillis() + " sendInteger" );
		clientX.call( "receiveInteger" , new Wrapper( integerValue ) );
		
		// send number
		
		System.out.println( System.currentTimeMillis() + " sendDouble" );
		clientX.call( "receiveNumber" , new Wrapper( numberValue ) );
		
		// send string
		
		System.out.println( System.currentTimeMillis() + " sendString" );
		clientX.call( "receiveString" , new Wrapper( stringValue ) );
		
		// send array
		
		System.out.println( System.currentTimeMillis() + " sendArray" );
		clientX.call( "receiveArray" , new Wrapper( arrayValue ) );
		
		// send object
		
		System.out.println( System.currentTimeMillis() + " sendObject" );
		clientX.call( "receiveObject" , new Wrapper( objectValue ) );
		
	}

}
