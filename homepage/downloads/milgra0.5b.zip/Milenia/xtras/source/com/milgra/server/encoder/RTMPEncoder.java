package com.milgra.server.encoder;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * RTMPEncoder encodes RTMP Packets into raw binary data
 * 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20070821
 * 
 */

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

//import com.milgra.server.util.Converter;
import com.milgra.server.controller.SocketController;


public class RTMPEncoder extends Serializer
{
	
	public int write;			// bytes written per step
	public ByteBuffer buffer;
	public RTMPPacket [ ] packets;
	
	public SocketChannel socket;
	public SocketController controller;
	
	public int headerSize;
	public int headerFlag;
	public byte [ ] header;
	public RTMPPacket old;
	
	public int size;
	public int chunkSize;
	public int remaining;
	public byte flag;
	
	/**
	 * RTMPEncoder constuctor
	 * @param socketX
	 * @param controllerX
	 */
	
	public RTMPEncoder ( SocketController controllerX , SocketChannel socketX )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + controllerX.client.id + " RTMPEncoder.construct" );
		
		socket = socketX;
		controller = controllerX;
		
		buffer = ByteBuffer.allocate( 50000 );
		packets = new RTMPPacket[64 ];
		
		for ( int a = 0 ; a < 64 ; a++ ) 
		{
			
			packets[a ] = new RTMPPacket( );
			packets[a ].rtmpChannel = -1;
			packets[a ].flvChannel = -1;
			packets[a ].bodySize = 0;
			packets[a ].bodyType = 0;

		}
		
	}
	
	/**
	 * Adds new chunk
	 * @param chunkX
	 */
	
	public void add ( RTMPPacket packetX )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + controller.client.id + " RTMPEncoder.add rtmp: " + packetX.rtmpChannel + " flv: " + packetX.flvChannel + " type: " + packetX.bodyType + " size: " + packetX.bodySize );
		
		old = packets[packetX.rtmpChannel ];
		
		if ( old.flvChannel == packetX.flvChannel && packetX.rtmpChannel != 0x02 )
		{
			
			// flv channel is the same, length is 8
			
			headerSize = 8;
			headerFlag = 0x40;
			
			if ( old.bodyType == packetX.bodyType && old.bodySize == packetX.bodySize )
			{
				
				// body type and size is the same, length is 4
				
				headerSize = 4;
				headerFlag = 0x80;
				
				if ( old.flvStamp == packetX.flvStamp )
				{
					
					// flv stamp is the same, length is 1
					
					headerSize = 1;
					headerFlag = 0xC0;
					
				}
				
			}
			
		}
		else
		{
			
			// by default, header size is 12
			
			headerSize = 12;
			headerFlag = 0x00;
			
		}
		
		// store new values
		
		old.flvChannel = packetX.flvChannel;
		old.bodyType = packetX.bodyType;
		old.bodySize = packetX.bodyType;
		old.flvStamp = packetX.flvStamp;
		
		// header construction
		
		header = new byte [headerSize ];
		
		// create flag
		
		header[0 ] = ( byte )( headerFlag | packetX.rtmpChannel & 0x3F );
					
		if ( headerSize > 1 )
		{
			
			// put flv stamp
			
			header[1 ] = ( byte )( packetX.flvStamp >> 16 );
			header[2 ] = ( byte )( packetX.flvStamp >> 8 );
			header[3 ] = ( byte )( packetX.flvStamp );
			
			if ( headerSize > 4 )
			{
				
				// put body size and type
				
				header[4 ] = ( byte )( packetX.bodySize >> 16 );
				header[5 ] = ( byte )( packetX.bodySize >> 8 );
				header[6 ] = ( byte )( packetX.bodySize );
				header[7 ] = ( byte )( packetX.bodyType );
					
				if ( headerSize > 8 )
				{
						
					// put flv channel
					
					header[8 ] = ( byte )( packetX.flvChannel >> 24 );
					header[9 ] = ( byte )( packetX.flvChannel >> 16 );
					header[10 ]= ( byte )( packetX.flvChannel >> 8 );
					header[11 ]= ( byte )( packetX.flvChannel );
					
				}
				
			}
		
		}
		
		chunkSize = packetX.bodyType == 0x08 ? 65 : 128;
		remaining = packetX.bodySize;
		buffer.put( header );
		flag = ( byte ) ( header[0 ] | 0xC0 );

		//System.out.println( "position: " + buffer.position() + " bodySize: " + packetX.bodySize + " remaining: " + remaining );
		
		while ( remaining > 0 )
		{
			
			size = remaining < chunkSize ? remaining : chunkSize;
			buffer.put( packetX.body , packetX.bodySize - remaining , size );
			remaining -= size;
			if ( remaining > 0 ) buffer.put( flag );
			if ( buffer.position( ) > 45000 ) step( );
			
		}
		
	}
	
	/**
	 * Serializes rtmp chunks into raw binary data
	 * @param packetX The RTMP Packet
	 */
	
	public void step ( )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + controller.client.id + " RTMPEncoder.step " );
		
		try
		{
			
			buffer.flip( );
			write = socket.write( buffer );
			buffer.clear( );
			controller.bytesOUT += write;
			
			//System.out.println( System.currentTimeMillis() + " " + controller.client.id + " write: " + write );
			
		}
		catch ( IOException exception )
		{
			
			//System.out.println( System.currentTimeMillis() + " " + controller.client.id + " EXCEPTION RTMPEncoder.sendChunk " +	exception.getMessage( ) );
			
		}
		
	}

}
