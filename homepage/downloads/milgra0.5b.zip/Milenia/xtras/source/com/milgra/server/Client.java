package com.milgra.server;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * Client class contains the methods and properties of ClientController class, which can be accessed for custom
 * application programmers.
 * 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20071016
 * 
 */

import java.util.HashMap;
import java.util.ArrayList;

import com.milgra.server.controller.ClientController;

public class Client 
{
	
	// client attributes
	
	public long id = 0;
	public long ping = 0;
	
	public long bytesIN = 0;
	public long bytesOUT = 0;
	
	public double bandIN = 0;
	public double bandOUT = 0;
		
	public String ip = "";
	public String agent = "";
	public String referrer = "";
	
	public boolean hasVideo = false;
	public boolean hasAudio = false;
	
	// static funcitons
	
	public static Server server;
	public static ArrayList < Client > getClients ( IApplication applicationX ) { return server.getClientList( applicationX );}
	public static HashMap < Double, String > getStreams ( ) { return server.getStreams( ); }
	public static Client createClient ( IApplication applicationX ) { return ( Client ) new ClientController( applicationX ); }
	
	// common functions
	
	public void addStreamEventListener ( EventListener streamELX ) { }
	public void addInvokeEventListener ( EventListener invokeELX ) { }
	public void addStatusEventListener ( EventListener statusELX ) { }

	public HashMap < Double , String > getPlayedStreams ( ) { return null; }	
	public HashMap < Double , String > getPublishedStreams ( ) { return null; }
		
	public void call ( String invokeID ) { }
	public void call ( String invokeID , Wrapper argumentX ) { }
	public void call ( String invokeID , ArrayList < Wrapper > argumentsX ) { }
	public void callResult ( String invokeID , Wrapper argumentX ) { }
	public void callResult ( String invokeID , ArrayList < Wrapper > argumentsX ) { }
	
	public void pauseStream ( double streamIDX , boolean stateX ) { }
	public void recordStream ( double streamIDX , boolean stateX ) { }
	public void deleteStream ( double streamIDX ) { }
	
	public void enableStreamPlay ( double streamIDX , String streamNameX ) { }
	public void disableStreamPlay ( double streamIDX , String streamNameX ) { }
	
	public void enableStreamPublish ( double streamIDX , String streamNameX , String modeX ) { }
	public void disableStreamPublish ( double streamIDX , String streamNameX ) { }	

	public double cloneStream ( double streamIDX , String streamNameX ) { return -1; }

	// functions used in passive mode
	
	public void accept ( Wrapper wrapperX ) { }
	public void reject ( Wrapper wrapperX ) { }
	public void detach ( ) { }
	
	// functions used in active mode
	
	public void connect ( String uriX , ArrayList < Wrapper > argumentsX ) { }
	public void publishStream ( String streamNameX , String modeX ) { }
	public void unpublishStream ( double streamNameX ) { }

}
