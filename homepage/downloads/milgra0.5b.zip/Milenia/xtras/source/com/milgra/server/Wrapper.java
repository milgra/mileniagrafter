package com.milgra.server;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * Wrapper class wraps various data types, used by AMFEncoder/AMFDecoder classes
 * 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20071016
 * 
 */

import java.util.HashMap;
import java.util.ArrayList;


public class Wrapper 
{

	public String type;
	public Object value;

	public int intValue;
	public long longValue;
	public double doubleValue;
	public String stringValue;
	public boolean booleanValue;
	public ArrayList < Wrapper > listValue;
	public HashMap < String , Wrapper > hashValue;
	
	
	public Wrapper ( )
	{
	
		type = "Null";
		value = null;
		
	}	
	
		
	public Wrapper ( int valueX )
	{
		
		type = "Integer";
		value = valueX;
		intValue = valueX;
		
	}
	
	
	public Wrapper ( long valueX )
	{
		
		type = "Long";
		value = valueX;
		longValue = valueX;

	}
	
	
	public Wrapper ( double valueX )
	{
		
		type = "Double";
		value = valueX;
		doubleValue = valueX;

	}
	
	
	public Wrapper ( String valueX )
	{

		type = "String";
		value = valueX;
		stringValue = valueX;

	}
	
	
	public Wrapper ( boolean valueX )
	{
		
		type = "Boolean";
		value = valueX;
		booleanValue = valueX;

	}
	
	
	public Wrapper ( ArrayList < Wrapper > valueX )
	{
		
		type = "ArrayList";
		value = valueX;
		listValue = valueX;

	}
	
	
	public Wrapper ( HashMap < String , Wrapper > valueX )
	{
		
		type = "HashMap";
		value = valueX;
		hashValue = valueX;

	}
	
	
}
