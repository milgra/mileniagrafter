package com.milgra.server.thread;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * JobThreadController Class
 * 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20071016
 * 
 */

import com.milgra.server.Wrapper;
import com.milgra.server.EventListener;
import com.milgra.server.util.Timer;
import com.milgra.server.thread.IJob;

import java.util.HashMap;


public class JobThreadController 
{
	
	public int threads;
	public int average;
	
	public int stepTime;
	public Timer timer;
	public HashMap < String , JobThreadPool > pools;
	
	/**
	 * JobThreadController constructor
	 * @param stepX
	 */
	
	public JobThreadController ( int stepX )
	{
		
		//System.out.println( System.currentTimeMillis() + " JobThreadController.construct" );
		
		stepTime = stepX;
		
		EventListener timerListener = new EventListener ( )
		{
			public void onEvent ( HashMap < String , Wrapper > eventX ) { update( ); } 
		};
		
		timer = new Timer( 5000 , timerListener );
		pools = new HashMap < String , JobThreadPool > ( );
		
		timer.start( );
		
	}
	
	/**
	 * Updates properties
	 */
	
	public void update ( )
	{
		
		//System.out.println( System.currentTimeMillis() + " JobThreadController.update" );		
		for ( JobThreadPool pool : pools.values( ) ) pool.update( );
		
	}
	
	/**
	 * Returns average execution time of group
	 */
	
	public double getGroupAverage ( String groupX ) 
	{
		
		//System.out.println( "JobThreadController.getGroupAverage " + groupX + " " + pools + " " + pools.containsKey( groupX ) );
		
		if ( !pools.containsKey( groupX ) ) return 0;
		return pools.get( groupX ).getAverageTime( );
		
	}
	
	/**
	 * Returns thread count of group
	 * @param groupX
	 * @return
	 */
	
	public double getGroupThreads ( String groupX ) 
	{ 
		
		//System.out.println( "JobThreadController.getGroupThreads " + groupX + " " + pools + " " + pools.containsKey( groupX ) );
		
		if ( !pools.containsKey( groupX ) ) return 0;
		return pools.get( groupX ).getThreadCount( );
		
	}
	
	/**
	 * Adds new job
	 * @param jobX
	 * @param groupX
	 */

	public void addJob ( IJob jobX , String groupX )
	{
		
		//System.out.println( System.currentTimeMillis() + " JobThreadController.addJob " + jobX + " " + groupX );
		
		if ( !pools.containsKey( groupX ) )
		{
			
			JobThreadPool pool = new JobThreadPool( stepTime , groupX );
			pools.put( groupX , pool );
			
		}
		
		pools.get( groupX ).addJob( jobX );
		
	}
	
	/**
	 * Removes job
	 * @param jobX
	 * @param groupX
	 */
	
	public void removeJob ( IJob jobX , String groupX )
	{

		//System.out.println( System.currentTimeMillis() + " JobThreadController.removeJob " + jobX + " " + groupX );

		pools.get( groupX ).removeJob( jobX );
		
	}	

}
