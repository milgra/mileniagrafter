package com.milgra.server.encoder;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * HSActive class implements active-side rtmp handshake
 * 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20071016
 * 
 */

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

import com.milgra.server.controller.SocketController;


public class HSActive extends Serializer 
{
	
	public int state = 0;
	public ByteBuffer buffer;
	public SocketChannel socket;
	public SocketController controller;
	
	/**
	 * Creates a HSActive instance
	 * @param controllerX SocketController
	 * @param socketX SocketChanne;
	 */
	
	public HSActive ( SocketController controllerX , SocketChannel socketX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + controllerX.id + " HSActive.construct" );
		
		socket = socketX;
		buffer = ByteBuffer.allocate( 3073 );
		controller = controllerX;
		
	}
	
	/**
	 * Steps one in handshake.
	 */
	
	public void step ( ) throws IOException 
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + controller.id + " HSActive.step" );
		
		try
		{
						
			if ( state == 0 ) sendStamp( );
			if ( state == 1 ) receiveAnswer( );
			if ( state == 2 ) sendConnection( );
			
		}
		catch ( IOException exception ) { throw exception; }
		
	}
	
	/**
	 * Sends first handshake chunk - 0x03 followed by 1536 bytes of random data, in this case zeros
	 * @throws IOException
	 */
	
	public void sendStamp ( ) throws IOException
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + controller.id + " HSActive.sendStamp " + 1537 );

		try
		{
			
			ByteBuffer stamp = ByteBuffer.allocate( 1537 );
			
			stamp.put( ( byte ) 0x03 );
			stamp.position( 0 );
			
			socket.write( stamp );
			
			state = 1;
			
		}
		catch ( IOException exception ) { throw exception; }
		
	}
	
	/**
	 * Receives server's answer, 0x03 followed by 1536 bytes from previous step followed by 1536 random bytes from server
	 * @throws IOException
	 */
	
	public void receiveAnswer ( ) throws IOException
	{

		//System.out.println( System.currentTimeMillis( ) + " " + controller.id + " HSActive.receiveAnswer " );
		
		try
		{
			
			int bytes = socket.read( buffer );	
			if ( bytes == -1 ) throw new IOException( "Disconnected at handshake" );
			if ( !buffer.hasRemaining() ) state = 2;
			
		}
		catch ( IOException exception ) { throw exception; }
		
	}
	
	/**
	 * Last step, send back second 1536 bytes, then tells ClientController to send connection invoke
	 * @throws IOException
	 */
	
	public void sendConnection ( ) throws IOException
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + controller.id + " HSActive.sendConnection " + 1536 );

		try
		{

			ByteBuffer stamp = ByteBuffer.allocate( 1536 );
			buffer.position( 1537 );
			
			stamp.put( buffer );
			stamp.rewind( );
			
			socket.write( stamp );
			controller.startCommunication( );
			
		}
		catch ( IOException exception ) { throw exception; }
		
	}
	
	public void add ( RTMPPacket packetX ) { }

}
