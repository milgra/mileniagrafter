package com.milgra.server.controller;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * StreamPlayer class
 * 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20071016
 * 
 */

import com.milgra.server.Server;
import com.milgra.server.encoder.RTMPPacket;
import java.util.ArrayList;

public class StreamPlayer 
{
	
	public static Server server;
	public StreamController controller;
	
	// identifier
	
	public int flvChannel;
	public double id;
	public String name;
	
	// controllers
	
	public int videoChannel;
	public int audioChannel;
	
	// info
	
	public int size;
	public int type;
	
	// components
	
	public Object syncer;
	public StreamRouter router;
	
	// containers
	
	public ArrayList < RTMPPacket > temp;
	public ArrayList < RTMPPacket > list;
	
	
	/**
	 * StreamPlayer constructor
	 * @param controllerX
	 */
	
	public StreamPlayer ( double idX , StreamController controllerX )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + controllerX.client.id + " StreamPlayer.construct " + idX );
		
		id = idX;
		name = "";
		flvChannel = 0;
		
		videoChannel = 0;
		audioChannel = 0;
		
		size = 0;
		type = 0;
		
		temp = new ArrayList < RTMPPacket > ( );
		list = new ArrayList < RTMPPacket > ( );

		router = null;
		syncer = new Object( );
		controller = controllerX;
		
	}
	
	/**
	 * Closes streamplayer
	 */
	
	public void close ( )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + controller.client.id + " StreamPlayer.close " + id );
		if ( router != null ) router.unsubscribe( this );

	}
	
	/**
	 * StreamPlayer subscribe
	 * @param streamNameX
	 */
	
	public void subscribe ( String streamNameX )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + controller.client.id + " StreamPlayer.subscribe " + id + " " + streamNameX );
		
		if ( router != null ) router.unsubscribe( this );
		
		name = streamNameX;
		router = server.getStream( name );
		
		if ( router != null ) router.subscribe( this );
		
	}
	
	/**
	 * Adds new rtmp packet
	 * @param packetX
	 */
	
	public void addPacket ( RTMPPacket packetX )
	{
		
		//if ( controller.client.id == 0 ) System.out.println( System.currentTimeMillis() + " " + controller.client.id + " StreamPlayer.addPacket clientid: " + id + " streamName: " + name + " flvChannel: " + packetX.flvChannel + " bodySize: " + packetX.bodySize + " audioch: " + audioChannel + " videoch: " + videoChannel );

		RTMPPacket packet;
		
		switch ( packetX.bodyType )
		{
		
			case 0x08 :
				
				if ( controller.dropAudio ) return;
				
				packet = RTMPPacket.clonePacket( packetX );
				packet.flvChannel = flvChannel;
				packet.rtmpChannel = audioChannel;
				
				size += packet.bodySize;
				
				// routers thread and streamcontrollers thread at putPackets( ) can concure here
				
				synchronized ( syncer ) 
				{ 
					list.add( packet ); 
				}
				
				break;
				
			case 0x09 :
				
				type = packetX.body[0 ] & 0xF0;
				
				switch ( type )
				{
				
					case 0x30 :	if ( controller.dropDisposables ) return; break;
					case 0x20 : if ( controller.dropInterframes ) return; break;
					case 0x10 : if ( controller.dropKeyframes ) return; break;
					
				}
				
				packet = RTMPPacket.clonePacket( packetX );
				packet.flvChannel = flvChannel;
				packet.rtmpChannel = videoChannel;
				
				//System.out.println( packet.bodyType + " " + packet.bodySize + " " +  packet.flvChannel + " " + packet.rtmpChannel );
				
				size += packet.bodySize;

				synchronized ( syncer ) 
				{ 
					list.add( packet ); 
				}
				
				break;
		
		}
		
	}
	
	/**
	 * Places received packets into streamcontroller
	 */
	
	public void putPackets ( )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + id + " " + name + " " + controller.client.id + " StreamPlayer.putPackets " + list.size( ) );

		synchronized ( syncer )
		{
			
			controller.addOutgoingPackets( list );
			list.clear( );			
			
		}
		
	}

}
