package com.milgra.server.controller;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * StreamRouter class
 * 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20070821
 * 
 */

import java.util.ArrayList;

import com.milgra.server.Server;
import com.milgra.server.encoder.RTMPPacket;


public class StreamRouter
{
	
	public boolean closed;
	public static Server server;
	public StreamController controller;

	// identifiers

	public int flvChannel;
	public double id;
	public String name;
	public String mode;
	
	// controllers

	public int bufferLength;
	public long stamp;
	public boolean paused;
	public boolean change;

	// info

	public int bytes;
	public int byteRate;

	// buffer related
	
	public int peakTime;
	public int actualLength;
	public ArrayList < RTMPPacket > streamBuffer;
	
	// components
	
	public Object syncer;
	public StreamWriter writer;
	
	// containers

	public ArrayList < StreamPlayer > plus;
	public ArrayList < StreamPlayer > minus;
	public ArrayList < StreamPlayer > players;
	
	
	/**
	 * Creates new StreamRouter instance
	 */
	
	public StreamRouter ( double idX , StreamController controllerX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + controllerX.client.id + " StreamRouter.construct " + idX );
		
		id = idX;
		name = "";
		mode = "";
		flvChannel = 0;
		
		stamp = System.currentTimeMillis( );
		paused = true;
		change = false;
		bufferLength = 10;
		
		bytes = 0;
		byteRate = 0;

		actualLength = 0;
		streamBuffer = new ArrayList < RTMPPacket > ( ); 
		
		plus = new ArrayList < StreamPlayer > ( );
		minus = new ArrayList < StreamPlayer > ( );
		players = new ArrayList < StreamPlayer > ( );

		syncer = new Object( );
		writer = null;
		controller = controllerX;
			
	}
	
	/**
	 * Activates router
	 * @param streamNameX
	 * @param streamModeX
	 */
	
	public void route ( String streamNameX , String streamModeX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + controller.client.id + " StreamRouter.route " + id + " " + streamNameX + " " + streamModeX );

		name = streamNameX;
		mode = streamModeX;
		
		server.registerStream( name , this );
		if ( mode.equals( "record" ) ) writer = new StreamWriter( name );
		
		paused = false;
		
	}
	
	/**
	 * Closes router
	 */
	
	public void close ( )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + controller.client.id + " StreamRouter.close " + id );
		
		if ( !closed )
		{
			
			closed = true;
			server.unregisterStream( name , this );
			if ( writer != null ) writer.closeStream( );
			
			streamBuffer = null;
			
			plus = null;
			minus = null;
			players = null;
			
		}
		
	}
	
	/**
	 * Sets buffer length
	 * @param bufferLengthX
	 */
	
	public void setBufferLength ( int bufferLengthX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + controller.client.id + " StreamRouter.setBufferLength " + id + " " + bufferLengthX );

		bufferLength = bufferLengthX;
		if ( bufferLength < 50 ) bufferLength = 50;
		
	}
	
	/**
	 * Records stream
	 * @param stateX
	 */
	
	public void record ( boolean stateX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + controllerX.client.id + " StreamRouter.record " + id + " " + stateX );

		if ( stateX ) if ( writer == null ) writer = new StreamWriter( name );
		if ( !stateX ) if ( writer != null ) writer.closeStream( );
		
	}
	
	public void pause ( boolean stateX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + controllerX.client.id + " StreamRouter.pause " + id + " " + stateX );
		paused = stateX;

	}
	
	/**
	 * Adds a subscriber
	 * @param controllerX StreamController
	 */
	
	public void subscribe ( StreamPlayer playerX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + id + " StreamRouter.subscribe " + controllerX.id );
		
		if ( !closed )
		{
			synchronized ( syncer ) 
			{ 
				plus.add( playerX ); 
				change = true;
			}
		}
		
	}
	
	/**
	 * Removes a subscriber 
	 * @param controllerX
	 */
	
	public void unsubscribe ( StreamPlayer playerX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + id + " StreamRouter.unsubscribe " + controllerX.id );
		
		if ( !closed )
		{
			
			synchronized ( syncer ) 
			{ 
				minus.add( playerX ); 
				change = true;
			}
			
		}

	}
	
	/**
	 * Adds new rtmp packets
	 * @param packetX
	 */
	
	public void addPacket ( RTMPPacket packetX )
	{
		
		if ( !paused )
		{
			
			//if ( controller.client.id == 0 ) System.out.println( "\n" + System.currentTimeMillis( ) + " " + controller.client.id + " StreamRouter.addPacket clientid: " + id + " streamname: " + name + " flvchannel: " + packetX.flvChannel + " bodyType: " +  packetX.bodyType + " flvStamp: " + packetX.flvStamp + " bodySize: " + packetX.bodySize + " rtmpCahnnel: " + packetX.rtmpChannel );
			
			bytes += packetX.body.length;
			actualLength += packetX.flvStamp;
			
			streamBuffer.add( packetX );
			
			if ( writer != null ) writer.addPacket( packetX );
			
		}
		
	}
	
	/**
	 * Steps in routing
	 */
	
	public void step ( )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + controller.client.id + " StreamRouter.step " + id );

		if ( actualLength > bufferLength )
		{
			
			peakTime = actualLength - server.stepTime;
			
			while ( actualLength > peakTime && actualLength > 0 )
			{
					
				RTMPPacket packet = streamBuffer.remove( 0 );
				actualLength -= packet.flvStamp;
				for ( StreamPlayer player : players ) player.addPacket( packet );

			}
			
		}
			
		if ( change )
		{
			synchronized ( syncer )
			{
				
				players.addAll( plus );
				players.removeAll( minus );
				
				plus.clear( );
				minus.clear( );

				change = false;
				
			}
			
		}
		
		//if ( System.currentTimeMillis() - stamp > 5000 )
		//{
			
		//	byteRate = Math.round( bytes / 5 );
		//	stamp = System.currentTimeMillis( );
			
		//}
		
	}
	
}
