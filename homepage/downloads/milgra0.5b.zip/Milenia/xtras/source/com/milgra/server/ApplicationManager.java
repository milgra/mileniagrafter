package com.milgra.server;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * AppletManager Class reads application directory, loads and unloads applications
 * 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20070821
 * 
 */

import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.net.MalformedURLException;

import java.util.HashMap;
import java.util.ArrayList;


public class ApplicationManager 
{

	public File [ ]files;
	public Server server;
	
	public HashMap < String , File > applications;
	public HashMap < String , IApplication > actives;
	
	/**
	 * ApplicationManager constructor
	 */
	
	public ApplicationManager ( Server serverX )
	{
	
		//System.out.println( System.currentTimeMillis( ) + " AppletManager.construct" );
		
		server = serverX;
		actives = new HashMap < String , IApplication > ( );
		applications = new HashMap < String , File > ( );
		
	}
	
	/**
	 * Refreshes application list
	 */
	
	public void refreshList ( )
	{

		//System.out.println( System.currentTimeMillis( ) + " AppletManager.refreshList" );

		File directory = new File( "applications" );
		
		if ( directory.exists( ) ) 
		{
			
			files = directory.listFiles( );
			applications.clear( );
			
			for ( File file : files )
			{
				
				String fileID = file.getName( );
				String applicationID = fileID.substring( 0 , fileID.length() - 4 );
				
				applications.put( applicationID , file );
				
			}
		
		} 
		else System.out.println( "applications directory doesn't exists..." );
				
	}
	
	/**
	 * Returns application list
	 * @return applications
	 */
	
	public ArrayList < String > getList ( )
	{

		//System.out.println( System.currentTimeMillis( ) + " AppletManager.getList " );

		ArrayList < String > result = new ArrayList < String > ( );
		
		// get application list from directory
		
		result.addAll( applications.keySet( ) );
		
		// get deleted, but still running applications
		
		for ( String id : actives.keySet( ) )
			if ( !result.contains( id ) ) 
				result.add( id );
		
		return result;
		
	}
	
	/**
	 * Returns application state
	 * @param idX application id
	 * @return application state "running" "stopped"
	 */
	
	public String getState ( String idX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " AppletManager.getState " + idX );

		if ( actives.containsKey( idX ) ) return "running";
		else return "stopped";		
		
	}
	
	/**
	 * Loads all inactive applications at startup
	 */
	
	public void startUp ( )
	{
		
		//System.out.println( "ApplicationaManager.loadUp" );
		for ( String id : applications.keySet() ) loadApplication( id );
		
	}
	
	/**
	 * Re/Loads an application based on the file name of the class
	 */
	
	public void loadApplication ( String idX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " AppletManager.loadApplication " + idX );

		if ( actives.containsKey( idX ) ) return;
		
		try
		{
			
			File file = applications.get( idX );
			URL [ ] urls = { file.toURL() };
			ClassLoader classLoader = new URLClassLoader( urls );
			
			Class <?> newClass = classLoader.loadClass( "application.Application" );
			IApplication application = ( IApplication ) newClass.newInstance( );
			
			server.addApplication( idX , application );
			actives.put( idX , application );

		}
		catch ( IllegalAccessException exception )
		{
			System.out.println( System.currentTimeMillis() + " EXCEPTION: IllegalAccess AppletManager.loadApplet " + exception.getMessage( ) );
		}
		catch ( InstantiationException exception )
		{
			System.out.println( System.currentTimeMillis() + " EXCEPTION: Instantiation AppletManager.loadApplet " + exception.getMessage( ) );
		}
		catch ( MalformedURLException exception ) 
		{
			System.out.println( System.currentTimeMillis() + " EXCEPTION: MalformedURL AppletManager.loadApplet " + exception.getMessage( ) );
		}
		catch ( ClassNotFoundException exception )
		{
			System.out.println( System.currentTimeMillis() + " EXCEPTION: ClasSnotFound AppletManager.loadApplet " + exception.getMessage( ) );	
		}
		
	}

	/**
	 * Unloads an application, cleans up resources
	 * @param idX
	 */
	
	public void unloadApplication ( String idX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " AppletManager.unloadApplication " + idX );
		
		if ( !actives.containsKey( idX ) ) return;
		
		IApplication application = actives.remove( idX );
		
		// remove application from main list, so clients cannot connect 
		
		server.removeApplication( idX , application );
		
		// invokes cleanup scripts
		
		application.onClose( );
		
	}
	
	/**
	 * Returns application instance based on id
	 * @param idX
	 * @return
	 */
	
	public IApplication getApplication ( String idX )
	{
	
		//System.out.println( System.currentTimeMillis( ) + " AppletManager.getApplet " + idX );
		return actives.get( idX );
		
	}
	
	/**
	 * Returns application id based on instace
	 * @param applicationX
	 * @return
	 */
	
	public String getID ( IApplication applicationX )
	{
	
		//System.out.println( System.currentTimeMillis( ) + " AppletManager.construct " + applicationX );

		for ( String key : actives.keySet() ) 
			if ( actives.get( key ) == applicationX ) return key;
		
		return null;
		
	}

}
