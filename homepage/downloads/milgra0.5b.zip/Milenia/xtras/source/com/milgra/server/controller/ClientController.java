package com.milgra.server.controller;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * ClientClass is the main controller class of a client
 * 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20070821
 * 
 */

import java.nio.channels.SocketChannel;
import java.util.HashMap;
import java.util.ArrayList;

import com.milgra.server.Client;
import com.milgra.server.Server;
import com.milgra.server.Wrapper;
import com.milgra.server.IApplication;
import com.milgra.server.EventListener;

import com.milgra.server.util.Hexview;
import com.milgra.server.thread.IJob;

import com.milgra.server.encoder.AMFDecoder;
import com.milgra.server.encoder.MessageFactory;
import com.milgra.server.encoder.DecodeException;
import com.milgra.server.encoder.RTMPPacket;


public class ClientController extends Client implements IJob
{
	
	// static properties
	
	public static Server server;
	public static int pingDelay = 15000;
	
	// states
	
	public String mode;				// active or passive
	public IApplication application;
	
	// activity indicators
	
	public boolean closed;			// client has left
	public boolean accepted;		// client is accepted by an application	
	
	// amf packet tools
	
	public AMFDecoder decoder;
	public MessageFactory factory;
	
	// controllers
	
	public SocketController socketController;
	public StreamController streamController;
	
	// read and band info helpers\
	
	public int inMulti;
	public int outMulti;
	
	public long lastPingRead;
	public long lastPingSent;
	
	public long startStamp;
	
	public long lastBytesIN;
	public long lastBytesOUT;
	
	public double lastInMultiplier;
	public double lastOutMultiplier;
	
	public Object syncer;
	
	// event listeners
	
	public EventListener streamEL;
	public EventListener invokeEL;
	public EventListener statusEL;
	
	// packet containers
	
	public ArrayList < RTMPPacket > incomingList;
	public ArrayList < RTMPPacket > outgoingList;
	
	// container for incoming invoke channels and ids

	public HashMap < Double , String > incomingInvokes;
	public HashMap < String , Double > outgoingInvokes;
	public HashMap < Double , ArrayList < Wrapper > > publishInfos;

	
	/**
	 * ClientController constructor
	 */
	
	public ClientController ( IApplication applicationX )
	{
		
		server.addClient( this );		// server sets id
		
		// states
		
		application = applicationX;
		mode = application == null ? "passive" : "active";

		//System.out.println( System.currentTimeMillis( ) + " " + id + " ClientController.construct " + application );

		// activity indicators
		
		closed = false;
		accepted = false;
		
		// amf packet tools
		
		decoder = new AMFDecoder( this );
		factory = new MessageFactory( );
		
		// controllers
		
		socketController = new SocketController( this );
		streamController = new StreamController( this , socketController );
		
		// read and band info helpers

		lastPingSent = System.currentTimeMillis( );
		
		lastBytesIN = 0;
		lastBytesOUT = 0;
		
		syncer = new Object( );
		
		// containers

		incomingInvokes = new HashMap < Double , String > ( );
		outgoingInvokes = new HashMap < String , Double > ( );
		publishInfos = new HashMap < Double , ArrayList < Wrapper > > ( );		
		
		outgoingList = new ArrayList < RTMPPacket > ( );
		incomingList = new ArrayList < RTMPPacket > ( );

		// startup
		
		incomingInvokes.put( ( double ) 0 , null );
		if ( mode.equals( "active" ) ) server.registerClient( this , application );

	}
	
	/**
	 * ClientController destructor
	 */
	
	public synchronized void destruct ( )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + id + " ClientController.destruct " );
				
		// amf packet tools
		
		syncer = null;
		factory = null;
		application = null;
		
		// controllers
		
		socketController = null;
		streamController = null;
		
		// containers

		incomingInvokes = null;
		outgoingInvokes = null;
		
		outgoingList = null;
		incomingList = null;
		
	}
	
	/**
	 * Closes clientcontroller, cleanup
	 */
	
	public synchronized void close ( )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + id + " ClientController.close " );
		
		if ( !closed )
		{
			
			closed = true;
		
			server.removeClient( this );
			server.unregisterClient( this , application );
			server.removeControllers( this , socketController , streamController );
			
			streamController.close( );
			socketController.close( );
					
			if ( mode.equals( "passive" ) && application != null ) application.onLeave( this );
			if ( mode.equals( "active" ) && application != null ) dispatchStatusEvent( "status" , "NetConnection.Connect.Closed" , "" , null ); 
		
		}
					
	}
	
	/**
	 * Connects controller to an opened socket passed by ServerSocketConnector
	 * @param socketX
	 */
	
	public void connect ( SocketChannel channelX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + id + " ClientController.connect " +	channelX );
		
		if ( !closed )
		{
		
			socketController.connect( channelX , mode );
			server.addControllers( this , socketController , streamController );
			startStamp = System.currentTimeMillis();
			
		}
		
	}
	
	/**
	 * Connects controller to a remote server
	 * @param URLX
	 * @param argumentsX
	 */
	
	public void connect ( String urlX , ArrayList < Wrapper > argumentsX )
	{
	
		//System.out.println( System.currentTimeMillis( ) + " " + id + " ClientController.connect " + urlX );
		
		if ( !closed )
		{
		
			// get host and application id
			
			double invokeChannel = incomingInvokes.size( );
			
			String url = urlX.substring( 7 );
			String host = url.split( "/" )[0 ];
			String appid = url.split( "/" )[1 ];
	
			// adding connect invoke
			
			addOutgoingPacket( factory.connectMessage( appid , argumentsX , invokeChannel ) );	
			
			incomingInvokes.put( invokeChannel , "connect" );
			server.socketListener.connect( host , this );
		
		}
		
	}
	
	/**
	 * Channel connection failed
	 * @param detailsX
	 */
	
	public void connectFailed ( String detailsX )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + id + " ClientController.connectFailed " + detailsX );
		
		dispatchStatusEvent( "status" , "NetConnection.Connect.Failed" , detailsX , null );		
		close( );
		
	}

	/**
	 * Synchronized packet pushing
	 * @param packetX
	 */
	
	public void addOutgoingPacket ( RTMPPacket packetX ) 
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + id + " ClientController.addOutgoingPacket " + packetX );
		synchronized ( syncer ) { outgoingList.add( packetX ); }
		
	}

	/**
	 * Execution step
	 */
	
	public void step ( )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + id + " ClientController.step" );
		
		if ( !closed )
		{
				
			synchronized ( syncer )	{ socketController.sendDataPackets( outgoingList );
			outgoingList.clear( ); }
			
			socketController.getDataPackets( incomingList );
			for ( RTMPPacket packet : incomingList ) receivePacket( packet );
			incomingList.clear( );
			
			// get transfer from socket controller
				
			bytesIN = socketController.bytesIN;
			bytesOUT = socketController.bytesOUT;
			
			// batch tasks
			
			long roundTime = System.currentTimeMillis() - lastPingSent;
			if ( roundTime > pingDelay ) 
			{
				
				lastPingSent = System.currentTimeMillis( );
				addOutgoingPacket( factory.pingMessage( 6 , ( int ) lastPingSent & 0xffffffff , -1 , -1  ) );
				addOutgoingPacket( factory.readMessage( ( int ) bytesIN )); 
				
				// calculate bandwidth
							
				bandIN = ( bytesIN - lastBytesIN ) / ( pingDelay / 1000 );
				bandOUT = ( bytesOUT - lastBytesOUT ) / ( pingDelay / 1000 );
	
				lastBytesIN = bytesIN;
				lastBytesOUT = bytesOUT;

				hasVideo = streamController.hasVideo;
				hasAudio = streamController.hasAudio;
				
				streamController.hasAudio = false;
				streamController.hasVideo = false;
				
				/*
				System.out.println( "band: " + bandIN + " " + bandOUT );
					
				double inmult = Math.ceil( bandIN * 8 / 125000 );
				double outmult = Math.ceil( bandOUT * 8 / 125000 );
					
				if ( lastInMultiplier != inmult ) 
				{
					System.out.println( "inumlt: " + inmult + " " + lastInMultiplier );
					rtmpFlow.sendBandIn( (int)inmult * 125000 );
					lastInMultiplier = inmult;
				}
				
				if ( lastOutMultiplier != outmult )
				{
					System.out.println( "outumlt: " + outmult + " " + lastOutMultiplier );
					rtmpFlow.sendBandOut( (int)outmult * 125000 );
					lastOutMultiplier = outmult;
				}*/
				
			}
		
		} else destruct( );
		
	}
	
	/**
	 * Dispatches incoming data packets
	 * @param packetX
	 */
	
	public void receivePacket ( RTMPPacket packetX )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + id + " ClientController.receivePacket " + packetX.bodyType );
		
		switch ( packetX.bodyType )
		{
		
			case 0x03 : receiveRead( packetX ); break;
			case 0x04 : receivePing( packetX ); break;
			case 0x05 : receiveServerBW( packetX ); break;
			case 0x06 : receiveClientBW( packetX ); break;
			case 0x14 : receiveInvoke( packetX ); break;
			default   : receiveUnknown( packetX ); break;
		
		}
		
	}
	
	/**
	 * Receives read notification from client
	 * @param packetX
	 */
	
	public void receiveRead ( RTMPPacket packetX )
	{
	
		//System.out.println( System.currentTimeMillis( ) + " " + id + " ClientController.receiveRead " + Hexview.print( packetX.body ) );
		
		int readBytes = ( packetX.body[0 ] & 0xFF ) << 24 | 
						( packetX.body[1 ] & 0xFF ) << 16 |
						( packetX.body[2 ] & 0xFF ) << 8 |
						( packetX.body[3 ] & 0xFF );
		
		// sending it to stream controller
		streamController.setReadBytesByClient( readBytes );
		
	}
	
	/**
	 * Receives ping from client
	 * @param packetX
	 */
	
	public void receivePing ( RTMPPacket packetX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + id + " RTMPFlowController.receivePing " + Hexview.print( packetX.body ) );
		
		int type , p2 , p3 , p4;
		byte [ ] b = packetX.body;
		
		type = ( b[0 ] & 0xFF ) << 8 | ( b[1 ] & 0xFF );
		p2 = ( b[2 ] & 0xFF ) << 24 | ( b[3 ] & 0xFF ) << 16 | ( b[4 ] & 0xFF ) << 8 | ( b[5 ] & 0xFF );
		if ( b.length > 6 ) p3 = ( b[6 ] & 0xFF ) << 24 | ( b[7 ] & 0xFF )<< 16 | ( b[8 ] & 0xFF ) << 8 | ( b[9 ] & 0xFF );	else p3 = -1;
		if ( b.length > 10 ) p4 = ( b[10 ] & 0xFF ) << 24 | ( b[11 ] & 0xFF ) << 16 | ( b[12 ] & 0xFF ) << 8 | ( b[13 ] & 0xFF ); else p4 = -1;
		
		switch ( type )
		{
			
			// stream buffer length, sending it to router, and sending buffer clear ping message
			case 3 :
				
				streamController.setBufferLength( p2 , p3 );
				addOutgoingPacket( factory.pingMessage( 0 , p2 , -1 , -1 ) );
				break;
			
			// normal ping request
			case 6 :
				
				addOutgoingPacket( factory.pingMessage( 7 , p2 , p3 , p4 ) );
				break;
				
			// normal pong
			case 7 :
				
				ping = System.currentTimeMillis() - lastPingSent;
				if ( ping > 30000 ) detach( );
				break;
				
			// first ping ?
			case 8 :
				break;
				
			default :
				
				System.out.println( "Unknown ping message: " + Hexview.print( packetX.body ) );
				break;
		
		}
		
	}
	
	/**
	 * Receives server ( server side download ) bandwidth
	 * @param packetX
	 */
	
	public void receiveServerBW ( RTMPPacket packetX )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + id + " RTMPFlowController.receiveServerBW " + Hexview.print( packetX.body ) );

	}

	/**
	 * Receives client ( client side download ) bandwidth 
	 * @param packetX
	 */
	
	public void receiveClientBW ( RTMPPacket packetX )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + id + " RTMPFlowController.receiveClientBW " + Hexview.print( packetX.body ) );

	}
	
	/**
	 * Unknown packet type
	 * @param packet
	 */
	
	public void receiveUnknown ( RTMPPacket packetX )
	{
		
		System.out.println( System.currentTimeMillis( ) + " " + id + " ClientController.receiveUnknown " + packetX.bodyType + " " + packetX.rtmpChannel + " " + packetX.flvChannel + " " + packetX.body.length + " " + Hexview.print( packetX.body ) );
		
	}

	/**
	 * Receives invoke
	 * @param packetX
	 */
	
	public void receiveInvoke ( RTMPPacket packetX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + id + " ClientController.receiveInvoke " + Converter.print( packetX.body ) );
		
		try 
		{ 
			
			ArrayList < Wrapper > arguments = decoder.decodeInvoke( packetX.body ); 
			String invokeID = arguments.get( 0 ).stringValue;
			int callID = 8;
			
			if ( invokeID.equals( "createStream" ) ) callID = 1; else
			if ( invokeID.equals( "deleteStream" ) ) callID = 2; else
			if ( invokeID.equals( "play" ) ) callID = 3; else
			if ( invokeID.equals( "publish" ) ) callID = 4; else
			if ( invokeID.equals( "_result" ) ) callID = 6; else
			if ( invokeID.equals( "connect") ) callID = 7;
			
			switch ( callID )
			{
			
				case 1 : onStreamCreateRequest( arguments , packetX ); break;
				case 2 : onStreamDeleteRequest( arguments , packetX ); break;
				case 3 : onStreamPlayRequest( arguments , packetX ); break;
				case 4 : onStreamPublishRequest( arguments , packetX ); break;
				case 6 : onResult( arguments , packetX ); break;
				case 7 : onClient( arguments ); break;
				case 8 : onInvoke( arguments ); break;
			
			}
			
		}
		catch ( DecodeException exception ) { sendStatus( "error" , "AMF.Decode.Error" , exception.getMessage( ) , "" ); }
		
	}

	
	/**
	 * Connection object from client, connection initialization
	 * @param argumentsX Conneciton arguments
	 */
	
	public void onClient ( ArrayList < Wrapper > argumentsX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + id + " ClientController.onClient " + argumentsX.size( ) );

		HashMap < String , Wrapper > info = argumentsX.get( 2 ).hashValue;
		
		// get agent info

		ip = socketController.socket.socket( ).getInetAddress( ).getHostAddress( );
		agent = info.get( "flashVer" ).stringValue;
		referrer = info.get( "swfUrl" ).stringValue;
		application = server.getApplication( info.get( "app" ).stringValue );
		
		if ( application != null )
		{
			
			double handshake = System.currentTimeMillis() - startStamp - server.stepTime;
			
			bandIN = socketController.bytesIN / ( handshake / 1000 );
			bandOUT = socketController.bytesOUT / ( handshake / 1000 );

			//System.out.println( bandIN + " " + bandOUT );
			
			inMulti = ( int ) Math.floor( bandIN * 8 / 125000 );
			outMulti = ( int ) Math.floor( bandOUT * 8 / 125000 );
			
			if ( inMulti < 1 ) inMulti = 1;
			if ( outMulti < 1 ) outMulti = 1;
			
			//System.out.println( "inMulti: " + inMulti + " outMulit " + outMulti );
			
			// send starting ping messages

			addOutgoingPacket( factory.bandInMessage( inMulti * 125000 ) );
			addOutgoingPacket( factory.bandOutMessage( outMulti * 125000 ) );
			addOutgoingPacket( factory.pingMessage( 8 ,	0 ,	1 ,	( int ) System.currentTimeMillis( ) & 0xffffffff ) );

			// set outgoing bandwidth
			
			streamController.bandwidth = bandOUT;
			
			// remove unnecessary arguments
			
			argumentsX.remove( 0 );
			argumentsX.remove( 0 );
			argumentsX.remove( 0 );

			// enter client
			
			synchronized ( application ) { application.onEnter( this , argumentsX ); }
			
		}
		else reject( new Wrapper( "No Application : " + info.get( "app" ).stringValue ) );	
		
	}

	/**
	 * Normal invoke from client
	 * @param argumentsX arguments
	 */
	
	public void onInvoke ( ArrayList < Wrapper > argumentsX )
	{
			
		String invokeID = argumentsX.remove( 0 ).stringValue;
		double invokeChannel = argumentsX.remove( 0 ).doubleValue;
	
		//System.out.println( System.currentTimeMillis( ) + " " + id + " ClientController.onInvoke " + invokeID + " " + invokeChannel );

		// remove enclosing null

		argumentsX.remove( 0 );	
		
		// store invoke and channel, if there is need for response
		
		if ( invokeChannel > 0 ) outgoingInvokes.put( invokeID , invokeChannel );
		
		// create event
		
		HashMap < String , Wrapper > event = new HashMap < String , Wrapper > ( );
		event.put( "clientid" , new Wrapper( id ) );
		event.put( "invokeid" , new Wrapper( invokeID ) );
		event.put( "arguments" , new Wrapper( argumentsX ) );
		
		// dispatch event
		
		if ( invokeEL != null ) invokeEL.onEvent( event );
		
	}

	/**
	 * Invoke result from client.
	 * @param argumentsX arguments
	 */

	public void onResult ( ArrayList < Wrapper > argumentsX , RTMPPacket packetX )
	{
		
		String invokeID;
		double invokeChannel;
			
		invokeChannel = argumentsX.get( 1 ).doubleValue;
		invokeID = incomingInvokes.remove( invokeChannel );
		
		//System.out.println( System.currentTimeMillis( ) + " " + id + " ClientController.onResult " + invokeChannel + " " + invokeID );
		
		if ( invokeID.equals( "connect" ) ) 
		{
			
			// result for connection object
			
			HashMap < String , Wrapper > info = argumentsX.get( 3 ).hashValue;
			String code = info.get( "code" ).stringValue;
			Wrapper appinfo = info.get( "application" );
			
			// following invoke channels must be over 1
			
			incomingInvokes.put( ( double ) 2 , invokeID );
			
			// if success, set accepted true, else close
			
			if ( code.equals( "NetConnection.Connect.Success" ) ) accepted = true;
			else close( );			
			
			// dispatch status event
			
			dispatchStatusEvent( "status" , "NetConnection.Connect.Success" , "" , appinfo );
			
		}
		else
		if ( invokeID.equals( "createStream" ) ) 
		{
			
			// invoke result for createStream
			
			streamController.onCreateStreamResult( argumentsX.get( 3 ).doubleValue );
			
		}
		
	}
	
	/**
	 * Sends status message to client
	 * @param levelX
	 * @param codeX
	 * @param descriptionX
	 * @param detailsX
	 */
	
	public void sendStatus ( String levelX , String codeX , String descriptionX , String detailsX )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + id + " ClientController.sendStatus " + levelX + " " + codeX + " " + descriptionX + " " + detailsX );
		
		RTMPPacket status = factory.statusMessage( id , levelX , codeX , descriptionX , detailsX );
		addOutgoingPacket( status );
		
	}
	
	/**
	 * Dispatches a status event
	 * @param levelX
	 * @param codeX
	 * @param descriptionX
	 * @param appinfo
	 */
	
	public void dispatchStatusEvent ( String levelX , String codeX , String descriptionX , Wrapper appinfo )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + id + " ClientController.dispatchStatusEvent " + levelX + " " + codeX + " " + descriptionX + " " + appinfo );
		
		if ( !closed )
		{
		
			HashMap < String , Wrapper > event = new HashMap < String , Wrapper > ( );
			event.put( "clientid" , new Wrapper( id ) );
			event.put( "level" , new Wrapper( levelX ) );
			event.put( "code", new Wrapper( codeX ) );
			event.put( "description" , new Wrapper( descriptionX ) );
			event.put( "application" , appinfo );
			
			statusEL.onEvent( event );
		
		}
		
	}
	
	/**
	 * Invoke call to client
	 * @param idX Invoke ID
	 * @param argumentsX Invoke arguments
	 */
	public void call ( String callIDX , ArrayList < Wrapper > argumentsX ) 
	{ 
		
		call( callIDX , false , argumentsX , 0 );
		
	}
	public void call ( String callIDX , Wrapper argumentX ) 
	{ 
		
		ArrayList < Wrapper > arguments = new ArrayList < Wrapper > ( );
		arguments.add( argumentX );
		call( callIDX , false , arguments , 0 );
		
	}
	public void call ( String callIDX ) { call( callIDX , false , null , 0 ); }
	public void call ( String callIDX , boolean responseX ) { call( callIDX , responseX , null , 0 ); }
	public void call ( String callIDX , boolean responseX , ArrayList < Wrapper > argumentsX ) { call( callIDX , responseX , argumentsX , 0 );	}
	public void call ( String callIDX , boolean responseX , ArrayList < Wrapper > argumentsX , int flvChannelX )
	{
		
		double invokeChannel = 0;
		
		if ( responseX ) 
		{
			invokeChannel = incomingInvokes.size( );
			incomingInvokes.put( invokeChannel , callIDX );
		}
		
		if ( !closed && accepted ) addOutgoingPacket( factory.invokeMessage( invokeChannel , flvChannelX , callIDX , argumentsX ) );

	}
	
	/**
	 * Invoke result callback to client
	 * @param idX Invoke ID to send result
	 * @param argumentsX arguments
	 */
	
	public void callResult ( String idX , Wrapper argument )
	{
	
		ArrayList < Wrapper > arguments = new ArrayList < Wrapper > ( );
		arguments.add( argument );
		callResult( idX , arguments );
		
	}
	
	
	public void callResult ( String idX , ArrayList < Wrapper > argumentsX )
	{
		
		//System.out.println( System.currentTimeMillis() + " ClientController.callResult " + idX + " " + argumentsX + " " + outgoingInvokes.containsKey( idX ) );
		
		if ( !closed ) 
		{
			
			if ( outgoingInvokes.containsKey( idX ) )
			{
				
				// if invoke channel exists
	
				double invokeChannel = outgoingInvokes.remove( idX );
				addOutgoingPacket( factory.invokeMessage( invokeChannel , 0x03 , "_result" , argumentsX ) );
				
			}
			else
			{
				
				// if no, drop status event
				
				HashMap < String , Wrapper > event;
				
				event = new HashMap < String , Wrapper > ( );
				event.put( "clientid" , new Wrapper( id ) );
				event.put( "level" , new Wrapper( "error" ) );
				event.put( "code" , new Wrapper( "Invoke.Callback.Failed" ) );
				event.put( "description" , new Wrapper( "No Callback Function Defined on client side for: " + idX ) );
				
				if ( statusEL != null ) statusEL.onEvent( event );
				
			}
		
		}
		
	}
		
	/**
	 * Accepts the client 
	 * @param wrapperX - an information object passed to the client
	 */
	
	public void accept ( Wrapper wrapperX )
	{

		//System.out.println( System.currentTimeMillis( ) + " " + id + " ClientController.accept" );
		
		if ( !closed && mode.equals( "passive" ) ) 
		{
			
			ArrayList < Wrapper > arguments = new ArrayList < Wrapper > ( );
			HashMap < String , Wrapper > map = new HashMap < String , Wrapper > ( );
			
			map.put( "code" , new Wrapper( "NetConnection.Connect.Success" ) );
			map.put( "level" , new Wrapper( "status" ) );
			map.put( "description" , new Wrapper( "Connection succeeded." ) );
			map.put( "application" , wrapperX );
			arguments.add( new Wrapper( map ) );
			
			addOutgoingPacket( factory.invokeMessage( 1 , 0x03 , "_result" , arguments ) );
	
			server.registerClient( this , application );
			accepted = true;
		
		}
		
	}
	
	/**
	 * Rejects the client, called from a custom applications. Sends a standard rejection object as onStatus
	 * @param wrapperX - an information object passed to the client
	 */
	
	public void reject ( Wrapper wrapperX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + id + " ClientController.reject" );
		
		if ( !closed && mode.equals( "passive" )) 
		{
	
			ArrayList < Wrapper > arguments = new ArrayList < Wrapper > ( );
			ArrayList < RTMPPacket > packets = new ArrayList < RTMPPacket > ( );		
			HashMap < String , Wrapper > map = new HashMap < String , Wrapper >( );
			
			map.put( "code" , new Wrapper( "NetConnection.Connect.Rejected" ) );
			map.put( "level" , new Wrapper( "status" ) );
			map.put( "description" , new Wrapper( "Connection rejected." ) );
			map.put( "application" , wrapperX );

			arguments.add( new Wrapper( map ) );

			packets.add( factory.invokeMessage( 1 , 0x03 , "_result" , arguments ) );
			
			// add packet immediatley
			
			socketController.sendDataPackets( packets );
			socketController.closeInited = true;
		
		}
		
	}
	
	/**
	 * Detaches the client
	 */
	
	public void detach ( )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + id + " ClientController.detach" );
		close( );
		
	}
	
	// event listener adding
	
	public void addStreamEventListener ( EventListener streamELX ) { streamEL = streamELX; }
	public void addInvokeEventListener ( EventListener invokeELX ) { invokeEL = invokeELX; }
	public void addStatusEventListener ( EventListener statusELX ) { statusEL = statusELX; }
	
	//
	//
	//	Stream Related Code
	//
	//
	
	/**
	 * Stream create request from client 
	 * @param argumentsX
	 * @param packetX
	 */
	
	public void onStreamCreateRequest( ArrayList < Wrapper > argumentsX , RTMPPacket packetX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + id + " ClientController.onStreamCreateRequest " + argumentsX.get( 1 ).doubleValue );
		outgoingInvokes.put( "createStream" , argumentsX.get( 1 ).doubleValue );
		streamController.createStream( );
		
	}
	
	/**
	 * Stream delete request from client
	 * @param argumentsX
	 * @param packetX
	 */
	
	public void onStreamDeleteRequest( ArrayList < Wrapper > argumentsX , RTMPPacket packetX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + id + " ClientController.onStreamDeleteRequest " + argumentsX );
		streamController.deleteStream( argumentsX.get( 3 ).doubleValue );
		
	}
	
	/**
	 * Stream play request from client
	 * @param argumentsX
	 * @param packetX
	 */
	
	public void onStreamPlayRequest( ArrayList < Wrapper > argumentsX , RTMPPacket packetX )
	{

		//System.out.println( System.currentTimeMillis( ) + " " + id + " ClientController.onStreamPlayRequest " + argumentsX );
		streamController.playRequest( argumentsX.get( 3 ).stringValue , packetX.flvChannel );

	}
	
	/**
	 * Stream publish request from client
	 * @param argumentsX
	 * @param packetX
	 */
	
	public void onStreamPublishRequest( ArrayList < Wrapper > argumentsX , RTMPPacket packetX )
	{

		//System.out.println( System.currentTimeMillis( ) + " " + id + " ClientController.onStreamPublishRequest " + argumentsX );
		streamController.publishRequest( argumentsX.get( 3 ).stringValue , packetX.flvChannel , argumentsX.get( 4 ).stringValue );
		
	}
	
	/**
	 * Dispatches a stream event
	 * @param idX
	 * @param streamIDX
	 * @param streamNameX
	 * @param streamModeX
	 */
	
	public void dispatchStreamEvent ( String idX , double streamIDX , String streamNameX , String streamModeX )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + id + " ClientController.dispatchStreamEvent " + idX + " " + streamIDX + " " + streamNameX + " " + streamModeX );
		
		if ( !closed )
		{
		
			HashMap < String , Wrapper > event = new HashMap < String , Wrapper > ( );
			event.put( "eventid" , new Wrapper( idX ) );
			event.put( "clientid", new Wrapper( id ) );
			event.put( "streamid" , new Wrapper( streamIDX ) );
			event.put( "streamname" , new Wrapper( streamNameX ) );
			event.put( "streammode" , new Wrapper( streamModeX ) );
			
			streamEL.onEvent( event );
		
		}
		
	}
	
	public HashMap < Double , String > getPlayedStreams ( ) { if ( !closed ) return streamController.getPlayedStreams( ); else return null;  }	
	public HashMap < Double , String > getPublishedStreams ( ) { if ( !closed ) return streamController.getPublishedStreams( ); else return null; }

	public double cloneStream ( double streamIDX , String newNameX ) { if ( !closed ) return streamController.cloneStream( streamIDX , newNameX ); else return -1; }

	public void pauseStream ( double streamIDX , boolean stateX ) { if ( !closed ) streamController.pauseStream( streamIDX , stateX ); }
	public void recordStream ( double streamIDX , boolean stateX ) { if ( !closed ) streamController.recordStream( streamIDX , stateX ); }
	public void deleteStream ( double streamIDX ) { if ( !closed ) streamController.deleteStream( streamIDX ); }
		
	public void enableStreamPlay ( double streamIDX , String streamNameX ) { if ( !closed ) streamController.enablePlay( streamIDX , streamNameX ); }
	public void disableStreamPlay ( double streamIDX , String streamNameX ) { if ( !closed ) streamController.disablePlay( streamIDX , streamNameX ); }
	
	public void enableStreamPublish ( double streamIDX , String streamNameX , String streamModeX ) { if ( !closed ) streamController.enablePublish( streamIDX , streamNameX, streamModeX ); }
	public void disableStreamPublish ( double streamIDX , String streamNameX ) { if ( !closed ) streamController.disablePublish( streamIDX , streamNameX ); }
	
	public void publishStream ( String streamNameX , String streamModeX ) { if ( !closed ) streamController.publishRemoteStream( streamNameX , streamModeX ); }
	public void unpublishStream ( String streamNameX ) { if ( !closed ) streamController.unpublishRemoteStream( streamNameX ); }
	
}
