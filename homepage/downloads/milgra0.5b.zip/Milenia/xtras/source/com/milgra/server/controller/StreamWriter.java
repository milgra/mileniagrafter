package com.milgra.server.controller;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * StreamWriter class writes incoming flv chunks to a file
 * 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20070821
 * 
 */

import java.io.File;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
import java.util.ArrayList;

import com.milgra.server.encoder.RTMPPacket;


public class StreamWriter 
{

	public int last = 0;
	public int stamp = 0;
	
	public String id;
	public boolean first = true;
	
	public BufferedOutputStream stream;
	
	public ArrayList < RTMPPacket > list;
	public ArrayList < RTMPPacket > temp;
	
	/**
	 * Creates a streamwriter instance, creates the file based on streamID
	 * @param streamID String
	 */
	
	public StreamWriter ( String streamID )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + streamID + " StreamWriter.construct " );

		id = streamID;
		last = 0;
		
		try
		{

			File file = new File( "streams" , streamID + ".flv");
			
			if ( file.exists( ) ) file.delete( );
			
			file.createNewFile( );
			
			FileOutputStream fileStream = new FileOutputStream( file );
			stream = new BufferedOutputStream( fileStream );
			
			// write flv header
			
			stream.write( 0x46 );	// F
			stream.write( 0x4C );	// L
			stream.write( 0x56 );	// V
			
			stream.write( 0x01 );	// version
			stream.write( 0x05 );	// type : audio and video
			
			stream.write( 0 );
			stream.write( 0 );
			stream.write( 0 );
			stream.write( 0x09 );	// header length, always 9
			
			// flush data
			
			stream.flush( );

		}
		catch ( IOException exception )
		{
			
			System.out.println( "!!! StreamWriter.construct " + exception.getMessage( ) );
			
		}
		
	}	
	
	/**
	 * Adds new rtmp packet to the file
	 * @param packetX RTMPPacket with a chunk
	 */
	
	public void addPacket ( RTMPPacket packetX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + id + " StreamWriter.addPacket" );
		
		try
		{
			
			// increase stamp time
			stamp += first ? 0 : packetX.flvStamp;
			first = false;
				
			// add previous chunk size
				
			stream.write( last >> 24 );
			stream.write( last >> 16 );
			stream.write( last >> 8 );
			stream.write( last );
			
			// create chunk header
			
			stream.write( packetX.bodyType );	// 0x09 video 0x08 audio
			
			// body size on three bytes
			
			stream.write( packetX.bodySize >> 16 );
			stream.write( packetX.bodySize >> 8 );
			stream.write( packetX.bodySize );
			
			// body stamp in milliseconds
			
			stream.write( stamp >> 16 );
			stream.write( stamp >> 8 );
			stream.write( stamp );
			
			// padding
			
			stream.write( 0 );
			stream.write( 0 );
			stream.write( 0 );
			stream.write( 0 );
			
			// add chunk body
			
			stream.write( packetX.body );
			
			// store chunk size without the chunk size bytes
			
			last = packetX.bodySize + 11;
						
			// flush
			
			stream.flush( );

		}
		catch ( IOException exception )
		{
			
			System.out.println( "!!! StreamWriter.addPacket " +  exception.getMessage( ) );
			
		}
		
	}
	
	/**
	 * Closes the file
	 */
	
	public void closeStream ( )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + id + " StreamWriter.closeStream" );
		
		try
		{
			
			stream.flush( );
			stream.close( );
			
		}
		catch ( IOException exception )
		{
			
			System.out.println( "!!! StreamWriter.closeStream " + exception.getMessage( ) );
			
		}
		
	}

}
