package com.milgra.server.thread;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * JobThread class is an IJob collector and executor
 * 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20071016
 * 
 */

import java.util.ArrayList;

public class JobThread extends Thread
{

	public String group;
	public Object syncer;

	public long newTime;		// netto time
	public long stepTime;		// brutto time
	public long executionTime;	// execution time
	
	public long after;			// timestamps
	public long before;
	
	public boolean alive;		// thread is running
	public boolean change;		// change in job list
	public boolean waiting;
	
	public ArrayList < IJob > jobs;		// job list
	public ArrayList < IJob > plus;		// jobs to add
	public ArrayList < IJob > minus;	// jobs to remove
	
	/**
	 * Creates a new JobThread instance
	 * @param timeX
	 */
	
	public JobThread ( int timeX , String groupX )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + groupX + " JobThread.construct " + timeX );

		group = groupX;
		stepTime = timeX;
		
		alive = true;
		change = false;
		syncer = new Object( );
		
		jobs = new ArrayList < IJob > ( );
		plus = new ArrayList < IJob > ( );
		minus = new ArrayList < IJob > ( );
		
	}
	
	/**
	 * Starts Thread
	 */
	
	public void run ( )
	{
		
		//System.out.println( System.currentTimeMillis() + " JobThread.run " + group + " " + Thread.currentThread() );
		
		while ( alive )
		{
			
			try
			{
								
				before = System.currentTimeMillis( );
				for ( IJob job : jobs ) job.step( );
				after = System.currentTimeMillis( );
				executionTime = after - before;

				//if ( executionTime > 2 ) System.out.println( System.currentTimeMillis() + " JobThread.step " + group + " " + executionTime );

				if ( change )
				{
					
					synchronized ( syncer )
					{

						for ( IJob job : plus ) jobs.add( job );
						for ( IJob job : minus ) jobs.remove( job );
						plus.clear( );
						minus.clear( );
					
						change = false;

					}
					
					if ( waiting ) this.wait( );
										
				}
								
				Thread.sleep( stepTime );
				
			}
			catch ( InterruptedException exception )
			{
				System.out.println( System.currentTimeMillis( ) + " EXCEPTION JobThread.run InterruptedException" );
			}

		}
		
		// remove containers
		
		jobs = null;
		plus = null;
		minus = null;
		
	}
	
	/**
	 * Adds new job
	 * @param jobX
	 */
	
	public void addJob ( IJob jobX )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + group +  " JobThread.addJob " + jobX );
		
		synchronized ( syncer ) 
		{ 
			plus.add( jobX ); 
			change = true;
		}		
		
	}
	
	/**
	 * Removes job
	 * @param jobX
	 */
	
	public void removeJob ( IJob jobX )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + group + " JobThread.removeJob " + jobX );
		
		synchronized ( syncer ) 
		{
			minus.add( jobX ); 
			change = true;
		}
		
	}
	
	/**
	 * Clears joblist
	 */
	
	public void finish ( )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + group + " JobThread.clear" );
		
		alive = false;
		
	}

}
