package com.milgra.server.controller;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * SocketController class is for controlling socketchannel input/outputs
 * 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20070821
 * 
 */

import java.io.IOException;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;

import com.milgra.server.Server;
import com.milgra.server.thread.IJob;

import com.milgra.server.encoder.HSActive;
import com.milgra.server.encoder.HSPassive;
import com.milgra.server.encoder.RTMPPacket;
import com.milgra.server.encoder.Serializer;
import com.milgra.server.encoder.RTMPEncoder;
import com.milgra.server.encoder.RTMPDecoder;
import com.milgra.server.encoder.DecodeException;


public class SocketController implements IJob
{

	public static Server server;

	// state indicators
	
	public boolean closed;
	public boolean closeInited;
	
	// starting read and write values ( rtmp handshake by default )
	
	public int bytesIN = 3073;
	public int bytesOUT = 3073;
	
	// synchronizers
	
	public Object syncIN;
	public Object syncOUT;
	
	// handshakers
	
	public HSActive hsa;
	public HSPassive hsp;
	
	// encdoers
	
	public RTMPEncoder rtmpe;
	public RTMPDecoder rtmpd;
	
	public Serializer encoder;
	public Serializer decoder;
	
	public SocketChannel socket;
	public ClientController client;

	// data containers
	
	public ArrayList < RTMPPacket > flvList;
	public ArrayList < RTMPPacket > dataList;
	public ArrayList < RTMPPacket > outgoingList;
	
	/**
	 * SocketController constructor
	 * @param socketX Socket
	 * @param tpyeX Socket controller type ( "active" "passive" )
	 */	

	public SocketController ( ClientController clientX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + clientX.id + " SocketController.construct" );

		client = clientX;

		closed = false;
		closeInited = false;
		
		syncIN = new Object( );
		syncOUT = new Object( );
		
		flvList = new ArrayList < RTMPPacket > ( );
		dataList = new ArrayList < RTMPPacket > ( );
		outgoingList = new ArrayList < RTMPPacket > ( );

	}
	
	public void destruct ( )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " SocketController.close" );		

		syncIN = null;
		syncOUT = null;
		
		flvList = null;
		dataList = null;
		
		hsa = null;
		hsp = null;
		
		rtmpe = null;
		rtmpd = null;
		
		encoder = null;
		decoder = null;
		
	}
	
	/**
	 * Closes socketController
	 */
	
	public void close ( )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " SocketController.close" );
		
		if ( !closed && socket != null  )
		{
			
			try
			{

				closed = true;
				socket.close( );
				client.close( );
				
			}
			catch ( IOException exception )
			{
				System.out.println( System.currentTimeMillis( ) + " " + client.id + " SocketController.disconnect " + exception.getMessage( ) );	
			}

		}
		
	}

	/**
	 * Connects controller to a socket channel
	 * @param socketX SocketChannel
	 * @param modeX client mode
	 */
	
	public void connect ( SocketChannel socketX , String modeX )
	{

		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " SocketController.connect " + socketX + " " + modeX );

		if ( !closed )
		{
			
			socket = socketX;
			
			hsa = new HSActive( this , socket );
			hsp = new HSPassive( this , socket );
			
			rtmpe = new RTMPEncoder( this , socket );
			rtmpd = new RTMPDecoder( this , socket );
			
			if ( modeX.equals( "active" ) )
			{

				encoder = hsa;
				decoder = hsa;

			}
			else
			{

				encoder = hsp;
				decoder = hsp;

			}
			
		}
		
	}
	
	/**
	 * Starts rtmp communication, after handshake done
	 */
	
	public void startCommunication ( )
	{

		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " SocketController.startCommunication" );

		encoder = rtmpe;
		decoder = rtmpd;
		
	}
	
	/**
	 * Steps one in serialization/deserialization 
	 */
	
	public void step ( )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " SocketController.step " + bytesIN );
		
		if ( !closed )
		{
		
			try
			{
				
				//if ( client.id == 0 ) System.out.println( System.currentTimeMillis() + " socket step outgoinglist: " + outgoingList.size() );
				
				synchronized ( syncOUT )
				{
					for ( RTMPPacket packet : outgoingList ) rtmpe.add( packet );
					outgoingList.clear( );
				}
				
				decoder.step( );
				encoder.step( );
				
				if ( closeInited ) close( );
			
			}
			catch ( IOException exception )
			{
			
				//System.out.println( System.currentTimeMillis() + " IOException: socketController.step " + exception.getMessage( ) );
				close( );
				
			}
			catch ( DecodeException exception )
			{
				
				System.out.println( System.currentTimeMillis() + " DecodeException: socketController.step " + exception.getMessage( ) );
				
				close( );
				
			}
			
		} else destruct( );
						
	}

	
	/**
	 * Sends data packets to RTMPEncoder
	 * @param packetsX
	 */
	
	public void sendDataPackets ( ArrayList < RTMPPacket > packetsX )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + client.id + " SocketController.sendDataPackets" );
		synchronized ( syncOUT ) { outgoingList.addAll( packetsX ); }
		
	}
	
	/**
	 * Sends flv packets to RTMPEncoder
	 * @param packetsX
	 */
	
	public void sendFLVPackets ( ArrayList < RTMPPacket > packetsX )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + client.id + " SocketController.sendFLVPackets" );
		synchronized ( syncOUT ) { outgoingList.addAll( packetsX ); }
		
	}
	
	/**
	 * Receives packets from RTMPDecoder
	 * @param packetsX
	 */
	
	public void receiveDataPacket ( RTMPPacket packetX )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + client.id + " SocketController.receiveDataPackets" );
		synchronized ( dataList )
		{
			dataList.add( packetX );
		}
		
	}
	
	/**
	 * Receives flv packets from RTMPDecoder
	 * @param packetsX
	 */
	
	public void receiveFLVPacket ( RTMPPacket packetX )
	{
		
		//if ( client.id == 0 ) System.out.println( System.currentTimeMillis() + " " + client.id + " SocketController.receiveFLVPackets" );
		synchronized ( flvList ) 
		{
			flvList.add( packetX ); 
		}
		
	}

	/**
	 * returns flv packets 
	 * @return
	 */
	
	public void getFLVPackets ( ArrayList < RTMPPacket > packetsX ) 
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " SocketController.getflvPackets " + flvList );
		
		synchronized ( flvList )
		{
			
			packetsX.addAll( flvList );
			flvList.clear( );
			
		}
		
	}
	
	/**
	 * Returns data packets 
	 * @return
	 */
	
	public void getDataPackets ( ArrayList < RTMPPacket > packetsX ) 
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " SocketController.getDataPackets" );

		synchronized ( dataList )
		{
			
			packetsX.addAll( dataList );
			dataList.clear( );
			
		}
		
	}

}
