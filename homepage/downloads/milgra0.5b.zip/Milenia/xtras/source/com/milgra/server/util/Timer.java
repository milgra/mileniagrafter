package com.milgra.server.util;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * Timer class 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20071016
 * 
 */

import com.milgra.server.EventListener;


public class Timer extends Thread 
{
	
	public long delay;
	public long after;
	public long before;
	public long worktime;
	public long newdelay;
	
	public boolean running;
	public EventListener event;
	
	/**
	 * Timer constructor
	 * @param delayX delay between events
	 * @param eventX the destination event
	 */
	
	public Timer ( long delayX , EventListener eventX )
	{

		delay = delayX;
		event = eventX;
		running = true;
		
	}
	
	/**
	 * Start
	 */
	
	public void run ( )
	{
		
		while ( running ) 
		{

			before = System.currentTimeMillis();
			event.onEvent( null );
			after = System.currentTimeMillis();

			worktime = after - before;
			newdelay = delay - worktime;

			if ( newdelay < 0 ) newdelay = 1;

			try 
			{
				Thread.sleep ( newdelay );
			} 
			catch ( InterruptedException exception ) 
			{

				System.out.println(System.currentTimeMillis() + " Timer.run : "	+ exception.getMessage());

			}

		}
		
	}
	
	/**
	 * Finishes thread
	 */
	
	public void finish ( )
	{
		
		running = false;
		
	}

}
