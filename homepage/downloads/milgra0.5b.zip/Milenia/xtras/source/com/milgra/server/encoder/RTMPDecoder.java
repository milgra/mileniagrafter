package com.milgra.server.encoder;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * RTMPDecoder decodes incoming raw binary data to rtmp chunks with header
 * 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20070821
 * 
 */

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

import com.milgra.server.controller.SocketController;
//import com.milgra.server.util.Converter;


public class RTMPDecoder extends Serializer
{
	
	public int max;						// data limit in bytearray
	public int read;					// bytes read per step
	public int start;					// last header position
	public byte [ ] data;				// working byte array
	public boolean hasPacket;			// decode state
	
	// instance related
	
	public ByteBuffer buffer;	
	public SocketChannel socket;
	public SocketController controller;
	
	public RTMPPacket [ ] packets;
		
	// decode info containers
	
	public int [ ] chunkSizes;
	public int [ ] remainings;

				
	/**
	 * RTMPDecoder constructor
	 * @param controllerX SocketController
	 * @param streamX InputStream
	 */
	
	public RTMPDecoder ( SocketController controllerX ,
						 	SocketChannel socketX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " RTMPDecoder.construct" );
		
		buffer = ByteBuffer.allocate( 50000 );
		socket = socketX;	
		packets = new RTMPPacket [64 ];
		controller = controllerX;
		
		// containers

		chunkSizes = new int[64 ];
		remainings = new int[64 ];
				
	}
	
	/**
	 * Fills up buffer for next deserialization
	 */
	
	public void step ( ) throws IOException , DecodeException
	{

		//System.out.println( System.currentTimeMillis() + " RTMPDecoder step" );
		
		try
		{
			
			read = socket.read( buffer );
			
			if ( read == -1 ) throw new IOException( "Connection closed." );
			if ( read == 0 ) return;
			
			controller.bytesIN += read;			
			readData( );
		
		}
		catch ( IOException exception ) 
		{ 
			
			//System.out.println( System.currentTimeMillis() + " " + controller.client.id + " IOEXCEPTION : RTMPDecoder step " + exception.getMessage() );
			throw exception;
			
		}
		catch ( DecodeException exception ) 
		{ 
			
			//System.out.println( System.currentTimeMillis() + " " + controller.client.id + " DECODEEXCEPTION : RTMPDecoder step " + exception.getMessage() );
			throw exception;
			
		}
		
	}
	
	/**
	 * Decodes rtmp header and chunks from binary data
	 * @throws DecodeException at incorrect header sizes
	 */
	
	public void readData ( ) throws DecodeException
	{
		
		//if ( controller.client.id == 0 ) System.out.println( System.currentTimeMillis() + " " + controller.client.id + " RTMPDecoder.readData " + buffer.position( ) );
		
		// set maximal position
		max = buffer.position( );
		
		// next header start
		start = 0;		
		
		// get actual data
		data = buffer.array( );
		
		// set packet state
		hasPacket = true;
		
		do
		{
			
			// bytes available

			if ( max - start > 0 )
			{
				
				// read header flag
				
				int headerFlag = data[start ];
				
				// get header size and packet rtmp channel
				
				int headerSize = headerFlag & 0xC0;
				int headerChannel = headerFlag & 0x3F;
				
				// get actual packet related to this rtmp channel
				
				if ( packets[headerChannel ] == null ) 
				{
					packets[headerChannel ] = new RTMPPacket( );
					packets[headerChannel ].rtmpChannel = headerChannel;
				}
				
				RTMPPacket packet = packets[headerChannel ];
				
				// set header size
				
				switch ( headerSize )
				{
				
					case 0xC0 : headerSize = 1; break;
					case 0x80 : headerSize = 4; break;
					case 0x40 : headerSize = 8; break;					
					case 0x00 : headerSize = 12; break;
					default	  : throw( new DecodeException( "Invalid header size: " + headerSize ) );
					
				}
				
				// bytes available
				
				if ( max - start >= headerSize ) 
				{ 
					
					if ( headerSize > 1 )
					{
						
						// set flv stamp
						packet.flvStamp = ( data[start + 1 ] & 0xFF ) << 16 | 
										  ( data[start + 2 ] & 0xFF ) << 8 | 
										  ( data[start + 3 ] & 0xFF );
						
				
					
						if ( headerSize > 4 )
						{
							
							// set body size
							packet.bodySize = ( data[start + 4 ] & 0xFF ) << 16 | 
											  ( data[start + 5 ] & 0xFF ) << 8 | 
											  ( data[start + 6 ] & 0xFF );
							
							// set type
							packet.bodyType = data[start + 7 ] & 0xFF;
							
							packet.body = new byte[packet.bodySize ];
							
							chunkSizes[headerChannel ] = packet.bodyType == 0x08 ? 65 : 128;
							remainings[headerChannel ] = packet.bodySize;
					
							if ( headerSize > 8 )
							{
							
								// set flv channel
								packet.flvChannel = ( data[start + 8 ] & 0xFF ) << 24 | 
													( data[start + 9 ] & 0xFF ) << 16 | 
													( data[start + 10 ] & 0xFF ) << 8 | 
													( data[start + 11 ] & 0xFF );
								
							}
							
						}
						
					}
					
					int remaining = remainings[headerChannel ];
					int chunkSize = chunkSizes[headerChannel ];
					
					// if chunk size is bigger than remaining, use remaining
										
					if ( chunkSize > remaining ) chunkSize = remaining;
					
					// bytes available
					
					if ( ( max - start - headerSize ) >= chunkSize )
					{
						
						//System.out.println( "start+header " + ( start + headerSize ) + "bodySize: " + packet.bodySize + " bodySize - remaining: " + ( packet.bodySize - remaining ));
						
						System.arraycopy( data , 
										  start + headerSize , 
										  packet.body , 
										  packet.bodySize - remaining , 
										  chunkSize );

						// modify position and remaining
						
						remainings[headerChannel ] -= chunkSize;
						
						if ( remainings[headerChannel ] == 0 ) 
						{
							
							//if ( controller.client.id == 0 ) System.out.println( System.currentTimeMillis() + " " + controller.client.id + " RTMDEncoder.receive rtmp: " + packet.rtmpChannel + " flv: " + packet.flvChannel + " type: " + packet.bodyType + " size: " + packet.bodySize );
							
							RTMPPacket newPacket = RTMPPacket.clonePacket( packet );
							if ( packet.bodyType == 0x08 || packet.bodyType == 0x09 ) controller.receiveFLVPacket( newPacket );
							else controller.receiveDataPacket( newPacket );
							
							packet.body = new byte [ packet.bodySize ];
							remainings[headerChannel ] = packet.bodySize;
							
							
						}
						
						// increase header start position, add chunk to collector
						
						start += headerSize + chunkSize;
						
					} 
					else hasPacket = false;
					
					// no data for chunk
										
				}
				else hasPacket = false;
				
				// no data for header
				
			}
			else hasPacket = false;
			
			// no data left in buffer
			
		} 
		while ( hasPacket );
		
		// reset buffer, put unprocessed bytes in the beginning
		
		buffer.clear( );
		buffer.put( data , start , max - start );
		
	}
	
}
