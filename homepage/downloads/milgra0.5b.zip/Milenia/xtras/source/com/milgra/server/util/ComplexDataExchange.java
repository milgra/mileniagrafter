package com.milgra.server.util;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * ComplexDataExchange Class
 * 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20071016
 * 
 */

import java.util.HashMap;
import java.util.ArrayList;

import com.milgra.server.Client;
import com.milgra.server.Wrapper;


public class ComplexDataExchange 
{
	
	public Client client;

	public HashMap < String , String [ ] > classes;
	public HashMap < String , HashMap < Long , ArrayList < Wrapper > > > datas;
	
	/**
	 * ComplexDataExchange construct
	 * @param clientX
	 */
	
	public ComplexDataExchange ( Client clientX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + "ComplexDataExchange.construct" );
		
		client = clientX;
		
		datas = new HashMap < String , HashMap < Long , ArrayList < Wrapper > > > ( );
		classes = new HashMap < String , String [ ] > ( );
		
	}
	
	/**
	 * adds new exchange class
	 * @param idX
	 * @param fieldsX
	 */
	
	public void addClass ( String idX  )
	{
		
		//System.out.println( System.currentTimeMillis( ) + "ComplexDataExchange.addClass " + idX );
		
		HashMap < Long , ArrayList < Wrapper > > data = new HashMap < Long , ArrayList < Wrapper > > ( );
		
		datas.put( idX , data );
		
		ArrayList < Wrapper > arguments = new ArrayList < Wrapper > ( );		
		arguments.add( new Wrapper( idX ) );
		client.call( "addClass" , arguments );
		
	}
	
	/**
	 * Removes an exchange class
	 * @param idX
	 */
	
	public void removeClass ( String idX )
	{

		//System.out.println( System.currentTimeMillis( ) + "ComplexDataExchange.removeClass " + idX );

		datas.remove( idX );
		
		ArrayList < Wrapper > arguments = new ArrayList < Wrapper > ( );
		arguments.add( new Wrapper( idX ) );		
		client.call( "addClass" , arguments );
		
	}
	
	/**
	 * Updates class data
	 * @param classX
	 * @param datasX
	 */
	
	public void update ( String classX , HashMap < Long , ArrayList < Wrapper > > datasX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " ComplexDataExchange.update " + classX );
		
		HashMap < Long , ArrayList < Wrapper > > add = new HashMap < Long , ArrayList < Wrapper > > ( );
		HashMap < Long , ArrayList < Wrapper > > change = new HashMap < Long , ArrayList < Wrapper  > > ( );
		
		ArrayList < Long > remove = new ArrayList < Long > ( );
		
		if ( datas.get( classX ) != null )
		{

			HashMap < Long , ArrayList < Wrapper > > old = datas.get( classX );
			HashMap < Long , ArrayList < Wrapper > > neu = datasX;
			
			ArrayList < Long > common = new ArrayList < Long > ( );
			
			// compare key
			
			for ( long key : neu.keySet() ) 
				if ( !old.containsKey( key ) ) add.put( key , neu.get( key ) );
			
			for ( long key : old.keySet() )
				if ( !neu.containsKey( key ) ) remove.add( key );
				else common.add( key );

			// compare values in common keys
			
			for ( long key : common )
			{
				
				ArrayList < Wrapper > oldValue = old.get( key );
				ArrayList < Wrapper > newValue = neu.get( key );
				ArrayList < Wrapper > changedFields = new ArrayList < Wrapper > ( );
				
				for ( int a = 0 ; a < oldValue.size( ) ; a++ )
				{
					
					String oldFieldValue = oldValue.get( a ).stringValue;
					String newFieldValue = newValue.get( a ).stringValue;
					
					if ( !oldFieldValue.equals( newFieldValue ) )
					{
						
						changedFields.add( new Wrapper( a ) );
						changedFields.add( new Wrapper( newFieldValue ) );
					
					}
					
				}
			
				if ( changedFields.size( ) > 0 ) change.put( key , changedFields );
				
			}
						
		} else add = datasX;
		
		datas.put( classX , datasX );
		
		// creating wrapped argument
		
		ArrayList < Wrapper > addWRP = new ArrayList < Wrapper > ( );
		ArrayList < Wrapper > removeWRP = new ArrayList < Wrapper > ( );
		ArrayList < Wrapper > changeWRP = new ArrayList < Wrapper > ( );
		ArrayList < Wrapper > updatePacket = new ArrayList < Wrapper > ( );
					
		// adding added elements
		
		for ( Long id : add.keySet( ) )
		{
			addWRP.add( new Wrapper( id ) );
			addWRP.add( new Wrapper( add.get( id ) ) );
		}
		
		// changed elements
		
		for ( Long id : change.keySet( ) )
		{
			
			changeWRP.add( new Wrapper( id ) );
			changeWRP.add( new Wrapper( change.get( id ) ) );
			
		}
		
		// removed elements
		
		for ( Long id : remove ) removeWRP.add( new Wrapper ( id ) );

		updatePacket.add( new Wrapper( classX ) );		// class identifier
		updatePacket.add( new Wrapper( addWRP ) );		// added elements
		updatePacket.add( new Wrapper( removeWRP ) );	// removed elements
		updatePacket.add( new Wrapper( changeWRP ) );	// changed elements
		
		client.call( "updateExchange" , updatePacket );
		
	}

}
