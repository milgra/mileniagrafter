package com.milgra.server.encoder;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * AMFDecoder class
 * 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20071016
 * 
 */

import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.ArrayList;

import com.milgra.server.Wrapper;
import com.milgra.server.controller.ClientController;

public class AMFDecoder 
{
	
	public ClientController client;
	
	public AMFDecoder ( ClientController clientX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + clientX.id + " AMFDecoder.construct" );
		client = clientX;
		
	}
	
	/**
	 * Decodes an invoke byte array
	 * @param bytesX byte array
	 * @return ArrayList containing values
	 */
	
	public ArrayList < Wrapper > decodeInvoke ( byte [ ] bytesX ) throws DecodeException
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " AMFDecoder.decodeInvoke" );
		
		Wrapper item;
		ByteBuffer buffer = ByteBuffer.wrap( bytesX );
		ArrayList < Wrapper > resultList = new ArrayList < Wrapper > ( );
		
		// going through the bytebuffer
		
		while ( buffer.hasRemaining( ) )
		{
			
			try
			{

				// decode actual element
				
				item = decode( buffer );
				
				// store decoded wrapper
				
				resultList.add( item );
				
			}
			catch ( DecodeException exception ) { throw( exception ); }			
									
		}
		
		return resultList;
		
	}
	
	/**
	 * Decodes a byte array containing amf data
	 * @param bufferX byte buffer
	 * @return java object
	 */
	
	public Wrapper decode ( ByteBuffer bufferX ) throws DecodeException
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " AMFDecoder.decode" );
		
		byte type = bufferX.get( );

		switch ( type )
		{
		
			case 0x00 : return decodeDouble( bufferX );
			case 0x01 : return decodeBoolean( bufferX ); 
			case 0x02 : return decodeString( bufferX ); 
			case 0x03 : return decodeObject( bufferX ); 
			case 0x05 : return new Wrapper( ); // null
			case 0x06 : return new Wrapper( ); // undefined
			case 0x08 : return decodeMixedArray( bufferX );
			case 0x0A : return decodeArray( bufferX );
			default   :	throw( new DecodeException( "Unknown AMF data type" ) );
					
		
		}
		
	}
	
	/**
	 * Decodes a double
	 * amf double : 0x00 type byte followed by 8 bytes as a 64-bit double precision floating point 
	 * @param double value
	 */
	
	public Wrapper decodeDouble ( ByteBuffer bufferX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " AMFDecoder.decodeDouble" );
		double result = bufferX.getDouble( );
		return new Wrapper( result );
		
	}
	
	/**
	 * decodes a boolean
	 * amf boolean : 0x01 type byte followed by 0x00 if false, 0x01 if true
	 * @param bufferX byte buffer
	 * @return boolean value
	 */
	
	public Wrapper decodeBoolean ( ByteBuffer bufferX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " AMFDecoder.decodeBoolean" );

		boolean result;
		result = ( bufferX.get() & 0xFF ) == 0 ? false : true;
		return new Wrapper( result );
		
	}
	
	/**
	 * decodes a String
	 * amf string: 0x02 type byte followed by the string size on two bytes 
	 * ( max length 64K - 1 ), followed by the chars in UTF8
	 * @param bufferX byte buffer
	 * @return the string
	 */
	
	public Wrapper decodeString ( ByteBuffer bufferX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " AMFDecoder.decodeString" );

		String result = "";		
		int size = bufferX.get( ) << 8 | bufferX.get( );
		
		for ( int a = 0 ; a < size ; a++ ) result += ( char ) bufferX.get( );		
		return new Wrapper( result );
		
	}
	
	/**
	 * Decodes an object
	 * amf object: 0x03 type byte followed by key ( String ) - value ( any AMF type ) pairs, closed by 0x00 0x00 0x09
	 * @param bufferX byte buffer
	 * @return HashMap containing object values
	 */
	
	public Wrapper decodeObject ( ByteBuffer bufferX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " AMFDecoder.decodeObject" );

		int endInt;
		String key;
		Wrapper value;
		
		HashMap < String , Wrapper > result = new HashMap < String , Wrapper >( );
		
		while ( bufferX.hasRemaining( ) )
		{
			
			// check ending

			endInt = bufferX.get( ) << 16 | bufferX.get( ) << 8 | bufferX.get( );
			
			if ( endInt != 9 )
			{
				
				bufferX.position( bufferX.position( ) - 3 );

				// get key and value pairs
				
				try
				{
					
					key = decodeString( bufferX ).stringValue;
					value = decode( bufferX );
					
					result.put( key , value );

				}
				catch ( DecodeException exception )
				{
					
					System.out.println( "AMFDecoder.decodeObject " + exception.getMessage() );
					bufferX.position( bufferX.capacity( ) );
					
				}
			
			} else break;
									
		}
		
		return new Wrapper( result );
		
	}

	/**
	 * Decodes an array
	 * @param bufferX byte buffer
	 * @return ArrayList containing array values
	 */
	
	public Wrapper decodeArray ( ByteBuffer bufferX )
	{

		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " AMFDecoder.decodeArray" );

		int count = 0;
		int size = bufferX.get( ) << 24 | bufferX.get() << 16 | bufferX.get( ) << 8 | bufferX.get( );
		ArrayList < Wrapper > result = new ArrayList < Wrapper > ( );
				
		while ( bufferX.hasRemaining( ) && count < size )
		{
			
			try
			{
				
				Wrapper wrapper = decode( bufferX );
				result.add( wrapper );
				count++;
				
			}
			catch ( DecodeException exception )
			{

				System.out.println( "AMFDecoder.decodeObject " + exception.getMessage() );
				bufferX.position( bufferX.capacity( ) );
				
			}
									
		}
		
		return new Wrapper( result );
		
	}
	

	/**
	 * Decodes a mixed array
	 * @param bufferX byte buffer
	 * @return ArrayList containing array values
	 */
	
	public Wrapper decodeMixedArray ( ByteBuffer bufferX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " AMFDecoder.decodeMixedArray" );
		String key;
		Wrapper value;

		int endInt;
		int size = bufferX.get( ) << 24 | bufferX.get() << 16 | bufferX.get( ) << 8 | bufferX.get( );
		ArrayList < Wrapper > result = new ArrayList < Wrapper > ( );
		
		while ( bufferX.hasRemaining( ) )
		{
			
			// check ending

			endInt = bufferX.get( ) << 16 | bufferX.get( ) << 8 | bufferX.get( );
			
			if ( endInt != 9 )
			{
				
				bufferX.position( bufferX.position( ) - 3 );

				// get key and value pairs
				
				try
				{
					
					key = decodeString( bufferX ).stringValue;
					value = decode( bufferX );
					
					result.add( value );

				}
				catch ( DecodeException exception )
				{
					
					System.out.println( "AMFDecoder.decodeObject " + exception.getMessage() );
					bufferX.position( bufferX.capacity( ) );
					
				}
			
			} else break;
									
		}
		
		result.remove( 0 );
		return new Wrapper( result );
		
	}
	
}
