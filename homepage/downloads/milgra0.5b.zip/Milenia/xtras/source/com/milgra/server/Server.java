package com.milgra.server;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * Server class
 * 
 * Creates a new Server class instance
 * Creates a socketConnector, which starts to listen on port 1935
 * Creates application manager, which reads available applicaitons, and loads them
 * Creates a job thread controller, which manages client, socket and stream controller stepping
 * 
 * Server is also a container for Clientclients, StreamRouters, and Applications
 * 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20071016
 * 
 */

import java.util.HashMap;
import java.util.ArrayList;

import com.milgra.server.thread.JobThreadController;
import com.milgra.server.controller.StreamPlayer;
import com.milgra.server.controller.StreamRouter;
import com.milgra.server.controller.ClientController;
import com.milgra.server.controller.SocketController;
import com.milgra.server.controller.StreamController;


public class Server 
{
	
	public int stepTime = 15;
	public long clientID = 0;
	
	public SocketConnector socketListener;
	public ApplicationManager applicationManager;
	public JobThreadController jobThreadController;
	
	public HashMap < String , StreamRouter > streams;
	public HashMap < Long , ClientController > clients;
	
	public HashMap < String , IApplication > applications;
	public HashMap < String , ArrayList < ClientController >  > controllers;
	
	/**
	 * Server constructor
	 */
	
	public Server ( )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " Server.construct" );
		
		// set clients static server property
		
		Client.server = this;
		
		StreamPlayer.server = this;
		StreamRouter.server = this;
		
		StreamController.server = this;
		SocketController.server = this;
		ClientController.server = this;
		
		// startup
		
		socketListener = new SocketConnector( );
		applicationManager = new ApplicationManager( this );
		jobThreadController = new JobThreadController( stepTime );
		
		// container init
		
		streams = new HashMap < String , StreamRouter > ( );
		clients = new HashMap < Long , ClientController > ( );
		
		controllers = new HashMap < String , ArrayList < ClientController > > ( );
		applications = new HashMap < String , IApplication > ( );
		
		// start listening
		
		jobThreadController.addJob( socketListener , "sockets" );
		
		// application startup
		
		applicationManager.refreshList( );
		applicationManager.startUp( );
		
	}
	
	/**
	 * Adds clients to jobthreadcontroller
	 * @param clientX ClientController
	 * @param socketX SocketController
	 * @param streamX StreamController
	 */
	
	public void addControllers ( ClientController clientX , 
								 SocketController socketX , 
								 StreamController streamX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " Server.addControllers " + clientX.id );

		jobThreadController.addJob( clientX , "clients" );
		jobThreadController.addJob( socketX , "sockets" );
		jobThreadController.addJob( streamX , "streams" );
		
	}
	
	/**
	 * Removes clients from jobthreadcontroller 
	 * Multiple Clientclients can invoke it from multiple jobThreads, so synchronization needed
	 * @param clientX
	 * @param socketX
	 * @param streamX
	 */
	
	public void removeControllers ( ClientController clientX ,
									SocketController socketX ,
									StreamController streamX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " Server.removeControllers " + clientX.id );

		synchronized ( clients )
		{
			
			jobThreadController.removeJob( clientX , "clients" );
			jobThreadController.removeJob( socketX , "sockets" );
			jobThreadController.removeJob( streamX , "streams" );
			
		}		
		
	}
	
	/**
	 * Adds a new application
	 * Creates new ArrayList for application related Clientclients
	 * @param idX application id
	 * @param applicationX application instance
	 */
	
	public void addApplication ( String idX , IApplication applicationX )
	{
		
		//System.out.println( System.currentTimeMillis() + " Server.addApplication " + idX + " " + applicationX );
		
		controllers.put( idX , new ArrayList < ClientController > ( ) );
		applications.put( idX , applicationX );
		
	}
	
	/**
	 * Removes an application
	 * @param idX application id
	 * @param applicationX applicaiton instance
	 */
	
	public void removeApplication ( String idX , IApplication applicationX )
	{
		
		//System.out.println( System.currentTimeMillis() + " Server.removeApplication " + idX );
		
		ArrayList < ClientController > actual = new ArrayList < ClientController > ( controllers.get( idX ) );
		for ( ClientController client : actual ) client.detach( );
		
		controllers.remove( idX );
		applications.remove( idX );
		
	}
	
	/**
	 * Adds a new client to client list
	 * Active Clientclients can be created by multiple threads in applications, so synchronization needed
	 * @param clientX
	 */
	
	public void addClient ( ClientController clientX )
	{
		
		//System.out.println( System.currentTimeMillis() + " Server.addClient " );

		synchronized ( clients ) 
		{
			
			clientX.id = clientID++;	
			clients.put( clientX.id , clientX );
			
		}
	
	}
	
	/**
	 * Removes client from client list
	 * @param clientX
	 */
	
	public void removeClient ( ClientController clientX )
	{
		
		//System.out.println( System.currentTimeMillis() + " Server.removeClient " );
		synchronized ( clients ) { clients.remove( clientX.id ); }

	}
	
	/**
	 * Registers a stream router
	 * @param streamNameX
	 * @param routerX
	 */
	
	public void registerStream ( String streamNameX , StreamRouter routerX )
	{

		//System.out.println( System.currentTimeMillis() + " Server.registerStream " + streamNameX + " " + routerX );
		synchronized ( streams ) { streams.put( streamNameX , routerX ); }
		
	}
	
	/**
	 * Unregisters a stream router
	 * @param streamNameX
	 * @param routerX
	 */
	
	public void unregisterStream ( String streamNameX , StreamRouter routerX )
	{
		
		//System.out.println( System.currentTimeMillis() + " Server.unregisterStream " + streamNameX + " " + routerX );
		synchronized ( streams ) { streams.remove( streamNameX ); }
		
	}
	
	/**
	 * Pairs a client with an application
	 * Multiple ClientControllers can invoke it from multiple threads, synchronization needed
	 * @param clientX
	 * @param applicationIDX
	 */
	
	public void registerClient ( ClientController clientX , IApplication applicationX )
	{
	
		//System.out.println( System.currentTimeMillis( ) + " Server.registerClinet " + clientX.id + " " + application );

		synchronized ( controllers ) 
		{
			
			for ( String id : applications.keySet( ) )
				if ( applications.get( id ) == applicationX ) 
					controllers.get( id ).add( clientX );
			
		}
		
	}
	
	/**
	 * Unpairs client with application
	 * Multiple ClientControllers can invoke it from multiple threads, synchronization needed
	 * @param clientX
	 * @param applicationIDX
	 */
	
	public void unregisterClient ( ClientController clientX , IApplication applicationX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " Server.unregisterClient " + clientX.id + " " + applicationIDX );

		synchronized ( controllers ) 
		{

			for ( String id : applications.keySet( ) )
				if ( applications.get( id ) == applicationX )
					controllers.get( id ).remove( clientX );
					
		}
		
	}
	
	/**
	 * Returns application instance by id
	 * @param idX
	 * @return
	 */
	
	public IApplication getApplication ( String idX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " Server.getApplication " + idX );
		return applications.get( idX );
		
	}
	
	/**
	 * Returns stream router
	 * @param streamIDX
	 * @return
	 */
	
	public StreamRouter getStream ( String streamNameX )
	{
		
		//System.out.println( System.currentTimeMillis() + " Server.getStreamRouter " + streamNameX );
		synchronized ( streams ) { return streams.get( streamNameX ); }
		
	}
	
	/**
	 * Returns stream name list
	 * @return
	 */
	
	public  HashMap < Double , String > getStreams ( )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " Server.getStreams " );
		
		HashMap < Double , String > result = new HashMap < Double , String > ( );
		for ( StreamRouter router : streams.values( ) )
			result.put( router.id , router.name );

		return result;
		
	}
	
	/**
	 * Returns client list
	 * @return
	 */
	
	public ArrayList < Client > getClientList ( IApplication applicationX )
	{
		
		//System.out.println( System.currentTimeMillis() + " Server.getClientList ");
		
		for ( String id : applications.keySet() )
			if ( applications.get( id ) == applicationX )
				return new ArrayList < Client > ( controllers.get( id ) );
		
		return null;
		
	}

	/**
	 * Collects application info
	 * @return
	 */
	
	public HashMap < Long , ArrayList < Wrapper > > collectApplications ( ) 
	{
		
		//System.out.println( System.currentTimeMillis( ) + " Server.collectApplications" );
		
		long index;
		ArrayList < String > list;
		HashMap < String , Long > idbinds;
		HashMap < Long , ArrayList < Wrapper > > applist;
		
		index = 0;
		idbinds = new HashMap < String , Long > ( );
		applist = new HashMap < Long , ArrayList < Wrapper > > ( );
		
		list = applicationManager.getList( );
		
		// build up list with all applications
		
		for ( String text : list )
		{
			
			ArrayList < Wrapper > app = new ArrayList < Wrapper > ( );
			app.add( new Wrapper ( text ) );
			app.add( new Wrapper ( applicationManager.getState( text ) ) );
			app.add( new Wrapper( 0 + "" ) );
			app.add( new Wrapper( 0 + "" ) );
			app.add( new Wrapper( 0 + "" ) );
			
			applist.put( index , app );
			idbinds.put( text , index );
			index++;
			
		}
		
		// fill up active applications properties

		for ( String id : controllers.keySet( ) )
		{
			
			long appid = idbinds.get( id );
			ArrayList < Wrapper > app = applist.get( appid );
			ArrayList < ClientController > clientList = controllers.get( id ); 
			
			int incoming = 0;
			int outgoing = 0;
				
			for ( ClientController client : clientList )
			{
					
				incoming += client.bandIN * 8;
				outgoing += client.bandOUT * 8;
					
			}
				
			app.get( 2 ).stringValue = clientList.size( ) + "";
			app.get( 3 ).stringValue = incoming + "";
			app.get( 4 ).stringValue = outgoing + "";
					
		}
		
		return applist;
		
	}
	
	/**
	 * Collects stream info
	 * @return
	 */
	
	public HashMap < Long , ArrayList < Wrapper > > collectStreams ( ) 
	{
		
		//System.out.println( System.currentTimeMillis( ) + " Server.collectStreams" );
		
		long index;
		HashMap < Long , ArrayList < Wrapper > > streamlist;
		
		index = 0;
		streamlist = new HashMap < Long , ArrayList < Wrapper > > ( );		
		
		synchronized ( streams )
		{
			
			for ( StreamRouter router : streams.values( ) ) 
			{
				
				ArrayList < Wrapper > stream = new ArrayList < Wrapper > ( );
				stream.add( new Wrapper( router.name ) );
				stream.add( new Wrapper( router.players.size( ) + "" ) );
				stream.add( new Wrapper( router.byteRate + "" ) );
				
				streamlist.put( index++ , stream );
				
			}

		}
		
		return streamlist;
		
	}
	
	/**
	 * Collects graph info
	 * @return
	 */
	
	public HashMap < Long , ArrayList < Wrapper > > collectGraphs ( )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " Server.collectGraphs" );

		ArrayList < Wrapper > graph;
		HashMap < Long , ArrayList < Wrapper > > graphlist;
		
		graph = new ArrayList < Wrapper > ( );
		graphlist = new HashMap < Long , ArrayList < Wrapper > > ( );
		
		// client info collection
		
		int active = 0;
		int passive = 0;
		double incoming = 0;
		double outgoing = 0;
		
		synchronized ( clients )
		{
		
			for ( ClientController controller : clients.values( ) )
			{
				
				incoming += controller.bandIN * 8;
				outgoing += controller.bandOUT * 8;
				
				active += controller.mode.equals( "active" ) ? 1 : 0;
				passive += controller.mode.equals( "passive" ) ? 1 : 0;
				
			}
		
		}
		
		incoming = incoming / 1000000; 
		outgoing = outgoing / 1000000;
		incoming = ( ( double ) Math.round( incoming * 1000 ) ) / 1000; 		
		outgoing = ( ( double ) Math.round( outgoing * 1000 ) ) / 1000; 
		
		graph.add( new Wrapper( incoming + outgoing + "" ) );
		graph.add( new Wrapper( incoming + "" ) );
		graph.add( new Wrapper( outgoing + "" ) );
				
		graph.add( new Wrapper( active + passive + "" ) );
		graph.add( new Wrapper( active + "" ) );
		graph.add( new Wrapper( passive + "" ) );
		
		graph.add( new Wrapper( jobThreadController.getGroupAverage( "sockets" ) + "" ) );
		graph.add( new Wrapper( jobThreadController.getGroupAverage( "streams" ) + "" ) );
		graph.add( new Wrapper( jobThreadController.getGroupAverage( "clients" ) + "" ) );
		
		graph.add( new Wrapper( jobThreadController.getGroupThreads( "sockets" ) + "" ) );
		graph.add( new Wrapper( jobThreadController.getGroupThreads( "streams" ) + "" ) );
		graph.add( new Wrapper( jobThreadController.getGroupThreads( "clients" ) + "" ) );
		
		graphlist.put( ( long ) 0 , graph );
		
		return graphlist;
		
	}
	
	/**
	 * Creates a new Server instance
	 * @param args
	 */
	
	public static void main ( String [ ] args )
	{
		
		System.out.print( "Milenia Grafter Server version 0.6b, Copyright (C) 2007 Milan Toth\n" );
		Server server = new Server( );
		
		// avoid compiler warning :D
		server.getClass( );
		
	}

}
