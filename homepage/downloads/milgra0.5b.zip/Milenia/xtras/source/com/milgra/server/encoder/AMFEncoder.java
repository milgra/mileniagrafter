package com.milgra.server.encoder;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * AMFEncoder class
 * 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20071016
 * 
 */

import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.ArrayList;

import com.milgra.server.Wrapper;


public class AMFEncoder 
{
	
	/**
	 * Encodes an ArrayList
	 * @param listX ArrayList
	 * @return byte array
	 */
	
	public byte [ ] encodeInvoke ( ArrayList < Wrapper > listX )
	{
		
		//System.out.println( System.currentTimeMillis() + " AMFEncoder.encodeInvoke" );
		
		byte [ ] part;
		byte [ ] result;
		byte [ ] newResult;
		
		result = new byte[0];
		
		for ( int a = 0 ; a < listX.size( ) ; a++ )
		{
			
			part = encode( listX.get( a ) );			
			newResult = new byte [ result.length + part.length ];
			
			System.arraycopy( result , 0 , newResult , 0 , result.length );
			System.arraycopy( part , 0 , newResult , result.length , part.length );
			
			result = newResult;
			
		}
		
		return result;
		
	}
	
	/**
	 * Encodes an Object
	 * @param object object
	 * @return byte array
	 */
	
	public byte [ ] encode ( Wrapper wrapper )
	{
		
		//System.out.println( System.currentTimeMillis() + " AMFEncoder.encode " + wrapper.type );

		byte [ ] result = new byte [ ] { 0x05 };
		
		if ( wrapper.type.equals( "Integer" ) ) return encodeDouble( wrapper );
		else
		if ( wrapper.type.equals( "Long" ) ) return encodeDouble( wrapper );
		else
		if ( wrapper.type.equals( "Double" ) ) return encodeDouble( wrapper );
		else
		if ( wrapper.type.equals( "String" ) ) return encodeString( wrapper );
		else
		if ( wrapper.type.equals( "Boolean" ) ) return encodeBoolean( wrapper );
		else
		if ( wrapper.type.equals( "HashMap" ) ) return encodeHashMap( wrapper );
		else
		if ( wrapper.type.equals( "ArrayList" ) ) return encodeArrayList( wrapper );
		else
		if ( wrapper.type.equals( "Null" ) ) return result;
		else 
		return result;
		
	}	
	
	/**
	 * Encodes a Double
	 * @param doubleX a double
	 * @return byte array
	 */
	
	public byte [ ] encodeDouble ( Wrapper wrapper )
	{
		
		//System.out.println( System.currentTimeMillis() + " AMFEncoder.encodeDouble" );

		Double number;
		ByteBuffer buffer;
		
		if ( wrapper.type == "Integer" ) wrapper.doubleValue = ( double ) wrapper.intValue;
		if ( wrapper.type == "Long" ) wrapper.doubleValue = ( double ) wrapper.longValue;
		
		number = wrapper.doubleValue;
		
		buffer = ByteBuffer.allocate( 9 );
		buffer.put( ( byte ) 0x00 );
		buffer.putDouble( number );
		
		return buffer.array( );
		
	}
	
	/**
	 * Encodes a String
	 * @param stringX String
	 * @return byte array
	 */
	
	public byte [ ] encodeString ( Wrapper wrapper )
	{

		//System.out.println( System.currentTimeMillis() + " AMFEncoder.encodeString" );

		int length;
		String string;
		ByteBuffer buffer;
		
		string = wrapper.stringValue;
		length = string.length( );
		
		buffer = ByteBuffer.allocate( length + 3 );
		buffer.put( ( byte ) 0x02 );
		buffer.put( ( byte ) ( length >> 8 ) );
		buffer.put( ( byte ) length );
		
		for ( int a = 0 ; a < string.length( ) ; a++ )
			buffer.put( ( byte ) string.charAt( a ) );
		
		return buffer.array( );
		
		
	}
	
	/**
	 * Encodes a boolean
	 * @param booleanX Boolean
	 * @return byte array
	 */
	
	public byte [ ] encodeBoolean ( Wrapper wrapper )
	{

		//System.out.println( System.currentTimeMillis() + " AMFEncoder.encodeBoolean" );

		Boolean booleen;
		ByteBuffer buffer;
		
		booleen = wrapper.booleanValue;
		buffer = ByteBuffer.allocate( 2 );
		buffer.put( ( byte ) 0x01 );
		
		if ( booleen ) buffer.put( ( byte ) 0x01 );
		else buffer.put( ( byte ) 0x00 );
		
		return buffer.array( );
		
	}
	
	/**
	 * Encodes a HashMap
	 * @param mapX HashMap
	 * @return byte array
	 */
	
	public byte [ ] encodeHashMap ( Wrapper wrapper )
	{
		
		//System.out.println( System.currentTimeMillis() + " AMFEncoder.encodeHashMap" );

		byte [ ] result;
		byte [ ] ending;
		
		byte [ ] rawKey;
		byte [ ] rawValue;
		byte [ ] newResult;
		
		Wrapper value;
		HashMap < String , Wrapper > map = wrapper.hashValue;
		
		result = new byte[1 ];
		result[0 ] = ( byte ) 0x03;
		
		for ( String key : map.keySet( ) )
		{
			
			value = map.get( key );

			rawKey = encode( new Wrapper( key ) );			
			rawValue = encode( value );
			newResult = new byte[result.length + rawKey.length + rawValue.length - 1 ];
			
			System.arraycopy( result , 0 , newResult , 0 , result. length );
			System.arraycopy( rawKey , 1 , newResult , result.length , rawKey.length - 1 );
			System.arraycopy( rawValue , 0 , newResult , result.length + rawKey.length - 1 , rawValue.length );
			
			result = newResult;
			
		}
		
		ending = new byte[3 ];
		ending[2] = 0x09;
		
		newResult = new byte[result.length + 3 ];
		System.arraycopy( result , 0 , newResult , 0 , result. length );
		System.arraycopy( ending , 0 , newResult , result.length , 3 );
		
		return newResult;
		
	}
	
	/**
	 * Encodes an ArrayList
	 * @param mapX ArrayList
	 * @return byte array
	 */
	
	public byte [ ] encodeArrayList ( Wrapper wrapperX )
	{
		
		//System.out.println( System.currentTimeMillis() + " AMFEncoder.encodeArrayList" );
		
		byte [ ] result;
		byte [ ] rawValue;
		byte [ ] newResult;
		ArrayList < Wrapper > list = wrapperX.listValue;
		
		result = new byte[5 ];
		result[0 ] = ( byte ) 0x0A;
		result[1 ] = ( byte ) (list.size() << 24);
		result[2 ] = ( byte ) (list.size() << 16);
		result[3 ] = ( byte ) (list.size() << 8);
		result[4 ] = ( byte ) (list.size());
		
		for ( Wrapper wrapper : list )
		{
			
			rawValue = encode( wrapper );
			newResult = new byte[result.length + rawValue.length ];

			System.arraycopy( result , 0 , newResult , 0 , result. length );
			System.arraycopy( rawValue , 0 , newResult , result.length , rawValue.length );
			
			result = newResult;

		}
		
		return result;
		
	}

}
