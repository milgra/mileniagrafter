package com.milgra.server.encoder;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * HSPassive class implements passive-side rtmp handshake
 * 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20071016
 * 
 */

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

import com.milgra.server.controller.SocketController;


public class HSPassive extends Serializer
{
	
	public int state = 0;
	public ByteBuffer buffer;
	public SocketChannel socket;
	public SocketController controller;
	
	/**
	 * Creates a HSPassive instane
	 * @param controllerX the socket controller instance
	 * @param isX inputstream
	 * @param osX outputstream
	 */	
	
	public HSPassive ( SocketController controllerX , SocketChannel socketX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + controllerX.id + " HSPassive.construct" );

		socket = socketX;
		buffer = ByteBuffer.allocate( 1537 );
		controller = controllerX;
		
	}
	
	/**
	 * Step
	 */	
	
	public void step ( ) throws IOException
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + controller.id + " HSPassive.step" );
		
		try
		{
			
			if ( state == 0 ) receiveStamp( );
			if ( state == 1 ) sendAnswer( );
			if ( state == 2 ) receiveAnswer( );
			
		}
		catch ( IOException exception ) { throw exception; }
		
	}
	
	/**
	 * Receives stamp from client.
	 */	
	
	public void receiveStamp ( ) throws IOException
	{
			
		//System.out.println( System.currentTimeMillis( ) + " " + controller.id + " HSPassive.receiveStamp" );

		try 
		{
			
			int bytes = socket.read( buffer );
			if ( bytes == -1 ) throw new IOException( "Disconnected at handshake" );
			if ( buffer.remaining( ) == 0 )	state = 1;
			
		}
		catch ( IOException exception ) { throw exception; }
		
	}
	
	/**
	 * Sends answer
	 */
	
	public void sendAnswer ( ) throws IOException
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + controller.id + " HSPassive.sendAnswer " + 3073 );
		
		try
		{
		
			ByteBuffer answer = ByteBuffer.allocate( 3073 );
			
			answer.put( ( byte ) 0x03 );
			answer.put( buffer.array( ) , 1 , 1536 );
			answer.put( buffer.array( ) , 1 , 1536 );
			answer.rewind( );
			
			socket.write( answer );
			buffer = ByteBuffer.allocate( 1536 );
			
			state = 2;
			
		}
		catch ( IOException exception ) { throw exception; }
				
	}
	
	/**
	 * Receives clients answer
	 */
	
	public void receiveAnswer ( ) throws IOException
	{
				
		try
		{
			
			int bytes = socket.read( buffer );
			if ( bytes == -1 ) throw new IOException( "Disconnected at handshake" );
			if ( buffer.remaining( ) == 0 ) controller.startCommunication( );
			
		}
		catch ( IOException exception ) { throw exception; }
		
		
	}	

}
