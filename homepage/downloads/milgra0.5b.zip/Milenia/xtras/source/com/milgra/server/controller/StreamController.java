package com.milgra.server.controller;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * StreamController Class
 * 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20070821
 * 
 */

import java.util.HashMap;
import java.util.ArrayList;

import com.milgra.server.Server;
import com.milgra.server.Wrapper;
import com.milgra.server.thread.IJob;
import com.milgra.server.encoder.RTMPPacket;


public class StreamController implements IJob 
{
	
	public static Server server;

	// outgoing packets size counter

	public int size;
	public double bandwidth;
	
	public int channel;
	public double actualid;
	public double streamid;

	public boolean hasAudio;
	public boolean hasVideo;
	
	// outgoing bandwidth counter
		
	public int lastReadBytes;
	public int lastReadStamp;
	public long stamp;
	
	// frame drop control booleans
	
	public boolean dropAudio;
	public boolean dropKeyframes;
	public boolean dropInterframes;
	public boolean dropDisposables;
	
	// controllers
	
	public SocketController socket;
	public ClientController client;
	
	// packet containers
	
	public ArrayList < RTMPPacket > incomingList;
	public ArrayList < RTMPPacket > outgoingList;
	
	// stream containers
	
	public ArrayList < Integer > channels;
	public ArrayList < HashMap < String , String > > remoteRequests;
	
	public HashMap < Double , StreamPlayer > players;
	public HashMap < Double , StreamRouter > routers;
	public HashMap < Double , StreamRouter > cloners;
	public HashMap < Double , StreamPlayer > remotes;
	
	public HashMap < Integer , StreamPlayer > channelToPlayer;
	public HashMap < Integer , StreamRouter > channelToRouter;
	public HashMap < Integer , ArrayList < StreamRouter > > channelToCloner;
	
	/**
	 * StreamController constructor
	 * @param idX clients id
	 */
	
	public StreamController ( ClientController clientX , SocketController socketX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + idX + " StreamController.construct" );

		// controllers
		
		client = clientX;
		socket = socketX;
		
		// size counter
		
		size = 0;
		bandwidth = 0;
		
		// starting channel and id
		
		channel = 1 << 24;
		streamid = 1;
		
		lastReadBytes = 0;

		lastReadStamp = ( int ) System.currentTimeMillis( );
		stamp = ( int ) System.currentTimeMillis( );
		
		// stream containers
		
		players = new HashMap < Double , StreamPlayer > ( );
		routers = new HashMap < Double , StreamRouter > ( );
		cloners = new HashMap < Double , StreamRouter > ( );
		remotes = new HashMap < Double , StreamPlayer > ( );
		
		channelToPlayer = new HashMap < Integer , StreamPlayer > ( );
		channelToRouter = new HashMap < Integer , StreamRouter > ( );
		channelToCloner = new HashMap < Integer , ArrayList < StreamRouter > > ( );
		
		channels = new ArrayList < Integer > ( );

		// frame drop controls
		
		dropAudio = false;
		dropKeyframes = false;
		dropInterframes = false;
		dropDisposables = false;
		
		// packet containers

		incomingList = new ArrayList < RTMPPacket > ( );
		outgoingList = new ArrayList < RTMPPacket > ( );
		
		remoteRequests = new ArrayList < HashMap < String , String > > ( );

		// fill up channels from 6
		
		for ( int a = 6; a < 64 ; a++ ) channels.add( a );

	}
	
	/**
	 * Closes StreamController
	 */
	
	public void close ( )
	{

		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " StreamController.close" );
		
		for ( StreamPlayer player : players.values( ) ) player.close( );
		for ( StreamRouter router : routers.values( ) ) router.close( );
		for ( StreamRouter cloner : cloners.values( ) ) cloner.close( );
		for ( double id : remotes.keySet( ) )
		{
			ArrayList < Wrapper > arguments = new ArrayList < Wrapper > ( );
			arguments.add( new Wrapper( id ) );
			client.call( "deleteStream" , false , arguments );
		}
		
		players = null;
		routers = null;
		cloners = null;
		remotes = null;
		
		channelToPlayer = null;
		channelToRouter = null;
		channelToCloner = null;
		
		channels = null;

		incomingList = null;
		outgoingList = null;
		
		remoteRequests = null;
		
	}
	
	/**
	 * Creates new stream, passing back a newly generated stream id
	 */
	
	public void createStream ( )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " StreamController.createStream " );
		
		actualid = streamid++;
		client.callResult( "createStream" , new Wrapper( actualid ) );

	}
	
	/**
	 * Deletes a stream by id, called by custom application or client
	 * @param streamIDX
	 */
	
	public void deleteStream ( double streamIDX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " StreamController.deleteStream " + streamIDX );
		
		if ( players.containsKey( streamIDX ) )
		{
			
			StreamPlayer player = players.remove( streamIDX );
			channelToPlayer.remove( player.flvChannel );
			channels.add( player.videoChannel );
			channels.add( player.audioChannel );
			player.close( );
			
		}
		if ( routers.containsKey( streamIDX ) )
		{
			
			StreamRouter router = routers.remove( streamIDX );
			channelToRouter.remove( router.flvChannel );
			router.close( );
			
		}
		if ( cloners.containsKey( streamIDX ) )
		{
			
			StreamRouter cloner = cloners.remove( streamIDX );
			cloner.close( );
			
		}
		
		if ( client.streamEL != null ) client.dispatchStreamEvent( "delete" , streamIDX , "" , "" );
		
	}
	
	/**
	 * Stream play request from client
	 * @param streamNameX
	 * @param flvChannelX
	 */
	
	public void playRequest ( String streamNameX , int flvChannelX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " StreamController.playRequest " + streamNameX + " " + flvChannelX );
		
		// player for this channel doesn't exist yet
		if ( !channelToPlayer.containsKey( flvChannelX ) )
		{
			
			StreamPlayer player = new StreamPlayer( actualid , this );
			
			player.flvChannel = flvChannelX;
			player.videoChannel = channels.remove( 0 );
			player.audioChannel = channels.remove( 0 );
			
			players.put( actualid , player );
			channelToPlayer.put( flvChannelX , player );
			
		}
		
		double streamID = channelToPlayer.get( flvChannelX ).id;
		
		if ( client.streamEL == null ) enablePlay( streamID , streamNameX ); 
		else client.dispatchStreamEvent( "play" , streamID , streamNameX , "" );
		
	}
	
	/**
	 * Stream publish request from client
	 * @param streamNameX
	 * @param flvChannelX
	 * @param streamModeX
	 */
	
	public void publishRequest ( String streamNameX , int flvChannelX , String streamModeX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " StreamController.publishRequest " + streamNameX + " " + flvChannelX + " " + streamModeX );
		
		// router for this channel doesn't exist yet
		if ( !channelToRouter.containsKey( flvChannelX ) )
		{
			
			StreamRouter router = new StreamRouter( actualid , this );
			
			router.flvChannel = flvChannelX;
			
			routers.put( actualid , router );
			channelToRouter.put( flvChannelX , router );
			channelToCloner.put( flvChannelX , new ArrayList < StreamRouter > ( ) );
			
		}
		
		double streamID = channelToRouter.get( flvChannelX ).id;
		
		if ( client.streamEL == null ) enablePublish( streamID , streamNameX , streamModeX );
		else client.dispatchStreamEvent( "publish" , streamID , streamNameX , streamModeX );
		
	}
	
	/**
	 * Starts stream playing, subscribes player to a router
	 * @param streamIDX
	 * @param streamNameX
	 */
	
	public void enablePlay ( double streamIDX , String streamNameX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " StreamController.enablePlay " + streamIDX + " " + streamNameX  );

		if ( players.containsKey( streamIDX ) )
		{
			players.get( streamIDX ).subscribe( streamNameX );
			client.addOutgoingPacket( client.factory.pingMessage( 0 , players.get( streamIDX ).flvChannel , -1 , -1 ) );

		}
		
	}
	
	/**
	 * Starts stream publishing, enables router
	 * @param streamIDX
	 * @param streamNameX
	 * @param streamModeX
	 */
	
	public void enablePublish ( double streamIDX , String streamNameX , String streamModeX )
	{

		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " StreamController.enablePublish " + streamIDX + " " + streamNameX + " " + streamModeX );

		if ( routers.containsKey( streamIDX ) ) 
			routers.get( streamIDX ).route( streamNameX , streamModeX );
		
	}
	
	/**
	 * Rejects stream playing, sends status message
	 * @param streamIDX
	 * @param streamNameX
	 */
	
	public void disablePlay ( double streamIDX , String streamNameX ) 
	{ 
		
		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " StreamController.disablePlay " + streamIDX + " " + streamNameX  );
		client.sendStatus( "error" , "NetStream.Play.Rejected" , streamNameX , "" );
		
	}
	
	/**
	 * Rejects stream publishing, sends status message
	 * @param streamIDX
	 * @param streamNameX
	 */
	
	public void disablePublish ( double streamIDX , String streamNameX )
	{
	
		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " StreamController.disablePublish " + streamIDX + " " + streamNameX  );
		client.sendStatus( "error" , "NetStream.Publish.Rejected" , streamNameX , "" );
		
	}
	
	/**
	 * Clones a router under a new id, on the same channel
	 * @param streamNameX
	 * @param newNameX
	 */
	
	public double cloneStream ( double streamIDX , String streamNameX )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + client.id + " StreamController.cloneStream " + streamIDX + " " + streamNameX + " " + routers.containsKey( streamIDX ) );
		
		if ( routers.containsKey( streamIDX ) )
		{
			
			double newID = streamid++;
			StreamRouter router = routers.get( streamIDX );			
			StreamRouter cloner = new StreamRouter( newID  , this );
			
			cloner.flvChannel = router.flvChannel;			
			cloner.route( streamNameX , router.mode );
			
			cloners.put( newID , cloner );
			channelToCloner.get( router.flvChannel ).add( cloner );
			
			return newID;
			
		}
		
		return -1;
				
	}
	
	/**
	 * Pauses a stream router
	 * @param streamNameX
	 */
	
	public void pauseStream ( double streamIDX , boolean stateX )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + client.id + " StreamController.pauseStream " + streamIDX + " " + stateX );
		if ( routers.containsKey( streamIDX ) ) 
			routers.get( streamIDX ).pause( stateX );
		
	}
	
	/**
	 * Records or Stops recording a stream
	 * @param streamIDX
	 * @param stateX
	 */
	
	public void recordStream ( double streamIDX , boolean stateX )
	{

		//System.out.println( System.currentTimeMillis() + " " + client.id + " StreamController.recordStream " + streamIDX + " " + stateX );
		if ( routers.containsKey( streamIDX ) ) 
			routers.get( streamIDX ).record( stateX );
		
	}
	
	/**
	 * Publishes stream to remote server
	 * @param streamNameX
	 * @param streamModeX
	 */
	
	public void publishRemoteStream ( String streamNameX , String streamModeX )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + client.id + " StreamController.publishRemoteStream " + streamNameX + " " + streamModeX );

		HashMap < String , String > request = new HashMap < String , String > ( );
		request.put( "name" , streamNameX );
		request.put( "mode" , streamModeX );
		
		remoteRequests.add( request );
		client.call( "createStream" , true );
		
	}
	
	/**
	 * Stream created on remote server, publish stream
	 * @param remoteStreamIDX
	 */
	
	public void onCreateStreamResult ( Double remoteStreamIDX )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + client.id + " StreamController.onCreateStreamResult " + remoteStreamIDX );

		HashMap < String , String > request = remoteRequests.remove( 0 );
		String streamName = request.get( "name" );
		String streamMode = request.get( "mode" );
				
		int newChannel = channel--;
		double newID = streamid++;
		
		StreamPlayer player = new StreamPlayer( newID , this );
		
		player.flvChannel = newChannel;
		player.audioChannel = channels.remove( 0 );
		player.videoChannel = channels.remove( 0 );
		player.subscribe( streamName );
		
		players.put( newID , player );
		remotes.put( remoteStreamIDX , player );
		channelToPlayer.put( newChannel , player );
		
		ArrayList < Wrapper > arguments = new ArrayList < Wrapper > ( );
		arguments.add( new Wrapper( streamName ) );
		arguments.add( new Wrapper( streamMode ) );
		
		client.call( "publish" , false , arguments , newChannel );

	}
	
	/**
	 * Deletes a stream published to remote server
	 * @param streamNameX
	 */
	
	public void unpublishRemoteStream ( String streamNameX )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + client.id + " StreamController.unpublihsRemotestream " + streamNameX );
		
		double streamID = -1;
		double remoteID = -1;
		
		for ( StreamPlayer player : players.values( ) ) if ( player.name.equals( streamNameX ) ) streamID = player.id;
		for ( StreamPlayer player : remotes.values( ) ) if ( player.name.equals( streamNameX ) ) remoteID = player.id;
		
		if ( streamID > -1 )
		{
			
			StreamPlayer player = players.get( streamID );
			player.close( );
			
			players.remove( streamID );
			remotes.remove( remoteID );
			
			channels.add( player.videoChannel );
			channels.add( player.audioChannel );
			
			ArrayList < Wrapper > arguments = new ArrayList < Wrapper > ( );
			arguments.add( new Wrapper( remoteID ) );
			client.call( "deleteStream" , false , arguments );
			
		}
				
	}
	
	/**
	 * Returns published stream list
	 * @return
	 */
	
	public HashMap < Double , String > getPublishedStreams ( ) 
	{
		
		//System.out.println( System.currentTimeMillis() + " " + client.id + " StreamController.getPublishedStreams " );

		HashMap < Double , String > result = new HashMap < Double , String > ( );
		for ( StreamRouter router : routers.values( ) ) result.put( router.id , router.name );
		for ( StreamRouter cloner : cloners.values( ) ) result.put( cloner.id , cloner.name );
		
		return result;
		
	}
	
	/**
	 * Returns played stream list
	 * @return
	 */
	
	public HashMap < Double , String > getPlayedStreams ( ) 
	{
		
		//System.out.println( System.currentTimeMillis() + " " + client.id + " StreamController.getPlayedStreams" );
		
		HashMap < Double , String > result = new HashMap < Double , String > ( );
		for ( StreamPlayer player : players.values( ) ) result.put( player.id , player.name );
		
		return result;
		
	}
	
	/**
	 * Sets the buffer length for the routers on the specified channel
	 * @param idX
	 * @param bufferLengthX
	 */
	
	public void setBufferLength ( double streamIDX , int bufferLengthX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " StreamController.setBufferLength " + streamIDX + " " + bufferLengthX );
		
		int flvChannel = -1;
		if ( routers.containsKey( streamIDX ) )
		{
			routers.get( streamIDX ).setBufferLength( bufferLengthX );
			flvChannel = routers.get( streamIDX ).flvChannel;
		}
		
		if ( flvChannel != -1 )
			if ( channelToCloner.containsKey( flvChannel ) )
				for ( StreamRouter router : channelToCloner.get( flvChannel ) ) router.setBufferLength( bufferLengthX );
		
	}
	
	/**
	 * Adds a packet to the outgoing waiting list. Called by a StreamPlayer
	 * @param packetX RTMP Packet
	 * @param streamIDX
	 */
	
	public void addOutgoingPackets ( ArrayList < RTMPPacket > listX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " StreamController.addOutgoingPackets " + listX.size( ) );
		outgoingList.addAll( listX );
		
	}
	
	/**
	 * Steps one in packet multiplexing
	 */
	
	public void step ( )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " StreamController.step ogList: " + outgoingList.size( ) );
		
		if ( !client.closed )
		{

			socket.getFLVPackets( incomingList );
			socket.sendFLVPackets( outgoingList );
			outgoingList.clear( );
						
			for ( RTMPPacket packet : incomingList )
			{
				
				if ( packet.bodyType == 0x09 ) hasVideo = true; else
				if ( packet.bodyType == 0x08 ) hasAudio = true;
				
				StreamRouter router = channelToRouter.get( packet.flvChannel );
				ArrayList < StreamRouter > clones = channelToCloner.get( packet.flvChannel );
				
				if ( router != null ) router.addPacket( packet );
				if ( clones != null ) for ( StreamRouter cloner : clones ) cloner.addPacket( packet ); 
						
			}
			
			for ( StreamRouter router : routers.values( ) ) router.step( );
			for ( StreamRouter cloner : cloners.values( ) ) cloner.step( );
			for ( StreamPlayer player : players.values( ) ) { player.putPackets( );	size += player.size; player.size = 0; }
					
			incomingList.clear( );
			
			if ( System.currentTimeMillis( ) - stamp > 1000 ) setDropping( );
						
		}
		
	}
	
	/**
	 * Sets dropping config for next 1 second
	 */
	
	public void setDropping ( )
	{
		
		//System.out.println( "size: " + size + " bandwidth: " + bandwidth );
		
		if ( bandwidth != 0 )
		{
			
			if ( size > bandwidth )
			{
				
				if ( !dropDisposables ) dropDisposables = true; else
				if ( !dropInterframes ) dropInterframes = true; else
				if ( !dropKeyframes ) dropKeyframes = true; else
				if ( !dropAudio ) dropAudio = true;
				
			} 
			else
			if ( size < bandwidth )
			{
				
				if ( dropAudio ) dropAudio = false; else
				if ( dropKeyframes ) dropKeyframes = false; else
				if ( dropInterframes ) dropInterframes = false; else
				if ( dropDisposables ) dropDisposables = false;
				
			}
		
		}

		size = 0;
		stamp = System.currentTimeMillis( );
		
	}
	
	/**
	 * Sets read byte count by client to control packet dropping
	 * @param bytesOUTX
	 */
	
	public void setReadBytesByClient ( int bytesOUTX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " " + client.id + " StreamController.setReadBytesByClient " + bytesOUTX );
		
		int mode = 2;
		
		// first notification since stream playing
		if ( lastReadBytes == 0 && players.size( ) > 0 ) mode = 0; else
		
		// second notification since stream playing
		if ( lastReadBytes > 0 && players.size( ) > 0  ) mode = 1; else
			
		// streams stopped
		if ( players.size( ) == 0 ) lastReadBytes = 0;
		
		switch ( mode )
		{
		
			case 0 :
				
				// store read and stamp
				
				lastReadBytes = bytesOUTX;
				lastReadStamp = ( int ) System.currentTimeMillis( );
				break;
				
			case 1 :
				
				// calculate bandwidth since last appearance
	
				int duration = ( int ) System.currentTimeMillis( ) - lastReadStamp;
				//int transfer = bytesOUTX - lastReadBytes;
				if ( duration / 1000 == 0 ) return;
				
				//bandwidth = ( int ) Math.round( transfer / ( duration / 1000 ) );
				
				//System.out.println( "bandwidth: " + bandwidth );
								
				lastReadBytes = bytesOUTX;
				lastReadStamp = ( int ) System.currentTimeMillis( );
				break;
		
		}
		
	}

}
