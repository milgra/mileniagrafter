package com.milgra.server.encoder;

public class RTMPPacket 
{
	
	public int rtmpChannel = 0x03;
	public byte [ ] body;
	
	public int bodyType = 0;
	public int bodySize = 0;
	
	public int flvStamp = 0;
	public int flvChannel = 0;
	
	
	
	public static RTMPPacket clonePacket ( RTMPPacket packetX )
	{
		
		RTMPPacket packet = new RTMPPacket( );

		packet.rtmpChannel = packetX.rtmpChannel;
		packet.body = packetX.body.clone( );
		
		packet.bodyType = packetX.bodyType;
		packet.bodySize = packetX.bodySize;
		
		packet.flvStamp = packetX.flvStamp;
		packet.flvChannel = packetX.flvChannel;
		
		return packet;
		
	}

}
