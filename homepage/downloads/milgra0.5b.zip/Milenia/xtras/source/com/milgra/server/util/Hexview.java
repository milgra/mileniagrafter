package com.milgra.server.util;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * Hexview Class views byte array bytes as hexa codes
 * 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20071016
 * 
 */

public class Hexview 
{
	
	/**
	 * Prints a byte array
	 * @param bytes
	 * @return
	 */
	
	public static String print ( byte [ ] bytes )
	{
		
		String result = "";
		
		for ( byte actual : bytes ) result += Hexview.getHexaValue( actual & 0xff ) + " ";
		return result;

	}
	
	/**
	 * Splits value into two four-bit parts, returns their hexa value
	 * @param valueX
	 * @return
	 */
	
	public static String getHexaValue ( int valueX )
	{

		String result = "";
		
		result += getHexaBits( valueX >> 4 );
		result += getHexaBits( valueX & 0x0F );
		
		return result;

	}
	
	/**
	 * Returns hexa value
	 * @param valueX
	 * @return
	 */
	
	public static String getHexaBits ( int valueX )
	{

		switch ( valueX )
		{
		
			case 15 : return "F";
			case 14 : return "E";
			case 13 : return "D";
			case 12 : return "C";
			case 11 : return "B";
			case 10 : return "A";
			default : return "" + valueX;
		
		}
		
	}

}
