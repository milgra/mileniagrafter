package com.milgra.server.thread;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * JobThreadPool Class
 * 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20071016
 * 
 */

import java.util.HashMap;
import java.util.ArrayList;
import java.util.Collections;
import com.milgra.server.thread.JobThread;


public class JobThreadPool 
{
	
	public String group;
	
	// helpers
	
	public int stepTime;
	public int executionTime;
	
	public int maxThreads;
	public int activeThreads;				// thread count
	
	public double averageTime;
	public double executionRatio;
	
	// containers
	
	public ArrayList < Integer > counts;
	public ArrayList < JobThread > threads;		
	public HashMap < IJob , Integer > jobs;	
	
	/**
	 * JobThreadPool constructor
	 * @param stepTimeX
	 */
	
	public JobThreadPool ( int stepTimeX , String groupX )
	{
		
		//System.out.println( System.currentTimeMillis() + " " + groupX + " JobThreadPool.construct" );
		
		group = groupX;
		stepTime = stepTimeX;
		maxThreads = 8;
		activeThreads = 1;
		
		jobs = new HashMap < IJob , Integer > ( );
		counts = new ArrayList < Integer > ( );
		threads = new ArrayList < JobThread > ( );
		
		// one thread is needed at startup
		
		for ( int a = 0 ; a < maxThreads ; a++ )
		{
			
			JobThread jobThread = new JobThread( stepTime , group );
			threads.add( jobThread );
			
		}
		
		counts.add( 0 );
		threads.get( 0 ).start( );
		
	}
	
	/**
	 * Returns properties
	 * @return
	 */
	
	public double getThreadCount ( ) { return activeThreads; }	
	public double getAverageTime ( ) { return averageTime; }
	
	/**
	 * Checks execution times
	 */	
	
	public void update ( )
	{
		
		//System.out.println( System.currentTimeMillis()  + " " + group + " JobThreadPool.update" );
		
		averageTime = 0;
		executionTime = 0;
		executionRatio = 0;
		
		for ( JobThread jobThread : threads ) executionTime += jobThread.executionTime;
		
		averageTime = executionTime / activeThreads;
		executionRatio = averageTime / stepTime;
		
		if ( executionRatio > .8 ) 
		{
			if ( activeThreads < maxThreads )
			{
				counts.add( 0 );
				threads.get( activeThreads ).start( );
				activeThreads++;

			}
		}
		
	}

	/**
	 * Adds a new job
	 * @param jobX
	 */
	
	public void addJob ( IJob jobX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " JobThreadPool.addJob " + jobX );

		synchronized ( jobs )
		{
			
			int min = Collections.min( counts );
			int pos = counts.indexOf( min );
			
			JobThread jobThread = threads.get( pos );
			
			jobThread.addJob( jobX );
			jobs.put( jobX , pos );
			counts.set( pos , min + 1 );
			
		}
				
	}
	
	/**
	 * Removes a job
	 * @param jobX
	 */
	
	public void removeJob ( IJob jobX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " JobThreadPool.removeJob " + jobX );
	
		if ( !jobs.containsKey( jobX ) ) return;
		
		synchronized ( jobs )
		{
			
			int pos = jobs.remove( jobX );
			int cnt = counts.get( pos );
			
			JobThread jobThread = threads.get( pos );
			
			jobThread.removeJob( jobX );
			jobs.remove( jobX );
			counts.set( pos , cnt - 1 );
			
		}

	}

}
