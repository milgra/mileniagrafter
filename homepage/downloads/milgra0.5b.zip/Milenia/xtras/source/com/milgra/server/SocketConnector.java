package com.milgra.server;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * SocketConnector class listens on port 1935 and also connects active sockets
 * 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20071016
 * 
 */

import java.io.IOException;
import java.net.InetSocketAddress;

import java.nio.channels.SocketChannel;
import java.nio.channels.ServerSocketChannel;

import java.util.HashMap;
import java.util.ArrayList;

import com.milgra.server.controller.ClientController;
import com.milgra.server.thread.IJob;


public class SocketConnector implements IJob
{
	
	public ServerSocketChannel channel;
	public ArrayList < ClientController > removal;
	
	public HashMap < SocketChannel , ClientController > sockets;
	
	public ArrayList < SocketChannel > accepted;
	public ArrayList < SocketChannel > rejected;
	
	/**
	 * Creates a new ServerSocketListener instance
	 * @param serverX main class
	 */
	
	public SocketConnector ( )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " ServerSocketListener.construct" );
		
		removal = new ArrayList < ClientController > ( );
		sockets = new HashMap < SocketChannel , ClientController > ( );
		
		accepted = new ArrayList < SocketChannel > ( );
		rejected = new ArrayList < SocketChannel > ( );
		
		try
		{
			
			channel = ServerSocketChannel.open( );
			channel.configureBlocking( false );
			channel.socket( ).bind( new InetSocketAddress( 1935 ) );
			
		}
		catch ( IOException exception )
		{
			
			System.out.println( System.currentTimeMillis() + 
								" ServerSocketListener.construct IOException " + 
								exception.getMessage( ) );
			
		}
		
	}
	
	/**
	 * Checks for connection
	 */
	
	public void step ( )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " ServerSocketListener.step" );
		
		try
		{
			
			// checking for connected socket
			
			SocketChannel socket = channel.accept( );
			ClientController client;
			
			
			if ( socket != null )
			{
			
				socket.socket( ).setKeepAlive( true );
				socket.configureBlocking( false );
				socket.socket().setKeepAlive( true );
				
				// creating new ClientController
				
				client = new ClientController( null );
				client.connect( socket );
				
			}
			
		}
		catch ( IOException exception )
		{
			
			System.out.print( System.currentTimeMillis() + 
							  "EXCEPTION: ServerSocketListener.step " + 
							  exception.getMessage( ) );
			
		}
		
		for ( SocketChannel socket : sockets.keySet() )
		{
			
			// checking for accepted socket
			
			try { if ( socket.finishConnect( ) ) accepted.add( socket ); }
			catch ( IOException exception )	{ rejected.add( socket ); }
			
		}
		
		// dispatch results
		
		for ( SocketChannel socket : accepted ) sockets.get( socket ).connect( socket );
		for ( SocketChannel socket : rejected ) sockets.get( socket ).connectFailed( "Connection failed" );
		
		// remove finished connections
		
		sockets.keySet( ).removeAll( accepted );
		sockets.keySet( ).removeAll( rejected );
		
		accepted.clear( );
		rejected.clear( );

	}
	
	/**
	 * Creates a socket and connects it to specific host
	 * @param hostX
	 * @param controllerX
	 */
	
	public void connect ( String hostX , ClientController controllerX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + " SocketConnector.connect " + hostX + " " + controllerX );
		
		try
		{
			
			SocketChannel socket = SocketChannel.open( );
	        InetSocketAddress address = new InetSocketAddress( hostX , 1935 );
	        
	        socket.configureBlocking( false );
	        socket.connect( address );
			socket.socket( ).setKeepAlive( true );
	        
	        sockets.put( socket , controllerX );
			
		}
		catch ( IOException exception )	
		{
			
			System.out.println( System.currentTimeMillis() + 
								" EXCEPTION: ServerSocketListener.connect " + 
								exception.getMessage( ) );
			
			controllerX.connectFailed( exception.getMessage( ) );
			
		}
		
	}

}
