package com.milgra.server.encoder;

/*
 * Milenia Grafter Server
 * 
 * Copyright (c) 2007 by Milan Toth. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 */

/**
 * PacketFactory is for creating specific RTMP messages 
 * 
 * @mail milgra@milgra.hu
 * @author Milan Toth
 * @version 20070821
 * 
 */

import java.util.HashMap;
import java.util.ArrayList;

import com.milgra.server.Wrapper;
import com.milgra.server.encoder.AMFEncoder;


public class MessageFactory 
{
	
	/**
	 * Creates an invoke message
	 * @param invokeChannelX invoke channel
	 * @param rtmpChannelX rtmp channel
	 * @param idX invoke id
	 * @param messageX message
	 * @return RMTPPacket
	 */
	
	public RTMPPacket invokeMessage ( double invokeChannelX , 
									  int flvChannelX ,
									  String callIDX , 
									  ArrayList < Wrapper > argumentsX )
	{
		
		//System.out.println( System.currentTimeMillis() + "PacketFactory.invokeObject " + invokeChannelX + " " + rtmpChannelX + " " + idX + " " + messageX );
				
		RTMPPacket packet = new RTMPPacket( );
		AMFEncoder encoder = new AMFEncoder( );
		ArrayList < Wrapper > invoke = new ArrayList < Wrapper >( );
		
		invoke.add( new Wrapper( callIDX ) );
		invoke.add( new Wrapper( invokeChannelX ) );
		invoke.add( new Wrapper( ) );
		if ( argumentsX != null ) invoke.addAll( argumentsX );
		
		packet.body = encoder.encodeInvoke( invoke );
		packet.bodyType = 0x14;
		packet.bodySize = packet.body.length;
		packet.flvChannel = flvChannelX;
		
		return packet;
		
	}
	
	/**
	 * Creates a status message
	 * @param clientIDX
	 * @param levelX
	 * @param codeX
	 * @param descriptionX
	 * @param detailsX
	 * @return
	 */
	
	public RTMPPacket statusMessage ( long clientIDX ,
											String levelX , 
											String codeX , 
											String descriptionX ,
											String detailsX ) 
	{
		
		//System.out.println( System.currentTimeMillis( ) + "PacketFactory.invokeObject " + invokeChannelX + " " + rtmpChannelX + " " + idX + " " + messageX );
		
		AMFEncoder encoder = new AMFEncoder( );
		RTMPPacket packet = new RTMPPacket( );
		ArrayList < Wrapper > invoke = new ArrayList < Wrapper > ( );
		HashMap < String , Wrapper > map = new HashMap < String , Wrapper >( );
		
		map.put( "code" , new Wrapper( codeX ) );
		map.put( "level" , new Wrapper( levelX ) );
		map.put( "details" , new Wrapper( detailsX ) );
		map.put( "clientid" , new Wrapper( clientIDX ) );
		map.put( "description" , new Wrapper( descriptionX ) );
		
		invoke.add( new Wrapper( "onStatus" ) );
		invoke.add( new Wrapper( 1 ) );
		invoke.add( new Wrapper( ) );
		invoke.add( new Wrapper( map ) );
		
		packet.body = encoder.encodeInvoke( invoke );
		packet.bodyType = 0x14;
		packet.bodySize = packet.body.length;
		
		return packet;
		
	}
		
	/**
	 * Creates a connect message
	 * @param idX
	 * @return
	 */
	
	public RTMPPacket connectMessage ( String idX , ArrayList < Wrapper > argumentsX , double invokeChannelX  )
	{
		
		//System.out.println( System.currentTimeMillis( ) + "PacketFactory.connectMessage " + invokeChannelX + " " + rtmpChannelX + " " + idX + " " + messageX );
		
		AMFEncoder encoder = new AMFEncoder( );
		RTMPPacket packet = new RTMPPacket( );
		ArrayList < Wrapper > invoke = new ArrayList < Wrapper > ( );
		HashMap < String , Wrapper > map = new HashMap < String , Wrapper >( );
		
		map.put( "app" , new Wrapper( idX ) );
		map.put( "fpad" , new Wrapper( false ) );
		map.put( "tcUrl" , new Wrapper( idX ) );
		map.put( "swfUrl" , new Wrapper( "" ) );
		map.put( "flashVer" , new Wrapper( "milenia grafter server" ) );
		map.put( "videoCodecs", new Wrapper( 124 ) );
		map.put( "audioCodecs", new Wrapper( 615 ) );
		map.put( "videoFunction", new Wrapper( 1 ) );
		map.put( "pageUrl", new Wrapper( ) );
		map.put( "objectEncoding", new Wrapper( 0 ) );
		
		invoke.add( new Wrapper( "connect" ) );
		invoke.add( new Wrapper( invokeChannelX ) );
		invoke.add( new Wrapper( map ) );
		invoke.addAll( argumentsX );
				
		packet.body = encoder.encodeInvoke( invoke );
		packet.bodyType = 0x14;
		packet.bodySize = packet.body.length;
		packet.rtmpChannel = 0x03;

		return packet;
		
	}
	
	/**
	 * Creates a ping message
	 * @param typeX
	 * @param stampX
	 * @return
	 */
	
	public RTMPPacket pingMessage ( int p1 , int p2 , int p3 , int p4 )
	{
		
		//System.out.println( System.currentTimeMillis( ) + "PacketFactory.pingMessage" + p1 + " " + p2 + " " + p3 + " " + p4 );

		int length = 6;
		RTMPPacket packet;
		byte [ ] pingbytes;
		
		packet = new RTMPPacket( );
		pingbytes = new byte[14 ];
		
		pingbytes[0 ] = ( byte ) ( p1 >> 8 );
		pingbytes[1 ] = ( byte ) ( p1 );
		pingbytes[2 ] = ( byte ) ( p2 >> 24 );
		pingbytes[3 ] = ( byte ) ( p2 >> 16 );
		pingbytes[4 ] = ( byte ) ( p2 >> 8 );
		pingbytes[5 ] = ( byte ) ( p2 );
		
		if ( p3 != -1 )
		{
			
			pingbytes[6 ] = ( byte ) ( p3 >> 24);
			pingbytes[7 ] = ( byte ) ( p3 >> 16 );
			pingbytes[8 ] = ( byte ) ( p3 >> 8 );
			pingbytes[9 ] = ( byte ) ( p3 );
			
			length = 10;
			
		}
		
		if ( p4 != -1 )
		{
			
			pingbytes[10 ] = ( byte ) ( p4 >> 24);
			pingbytes[11 ] = ( byte ) ( p4 >> 16 );
			pingbytes[12 ] = ( byte ) ( p4 >> 8 );
			pingbytes[13 ] = ( byte ) ( p4 );
			
			length = 14;
			
		}
		
		byte [ ] raw = new byte[length ];
		System.arraycopy( pingbytes , 0 , raw , 0 , length );
		
		packet.body = raw;
		packet.bodyType = 0x04;
		packet.bodySize = packet.body.length;
		packet.rtmpChannel = 0x02;			

		return packet;

	}

	/**
	 * Creates a band in message
	 * @param bandX
	 * @return
	 */
	
	public RTMPPacket bandInMessage ( int bandX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + "PacketFactory.bandInMessage " + bandX );

		RTMPPacket packet;
		
		byte [ ] pingbytes = new byte[4 ];
		pingbytes[0 ] = ( byte ) ( bandX >> 24 );
		pingbytes[1 ] = ( byte ) ( bandX >> 16 );
		pingbytes[2 ] = ( byte ) ( bandX >> 8 );
		pingbytes[3 ] = ( byte ) ( bandX );
		
		packet = new RTMPPacket( );
		packet.body = pingbytes;
		packet.bodyType = 0x05;
		packet.bodySize = packet.body.length;
		packet.flvChannel = 0;
		packet.rtmpChannel = 0x02;			

		return packet;
		
	}
	
	/**
	 * Creates a band out message
	 * @param bandX
	 * @return
	 */
	
	public RTMPPacket bandOutMessage (  int bandX )
	{
		
		//System.out.println( System.currentTimeMillis( ) + "PacketFactory.bandOutMessage " + bandX );
		
		RTMPPacket packet;		
		byte [ ] pingbytes;
		
		packet = new RTMPPacket( );
		pingbytes = new byte[5 ];
		
		pingbytes[0 ] = ( byte ) ( bandX >> 24 );
		pingbytes[1 ] = ( byte ) ( bandX >> 16 );
		pingbytes[2 ] = ( byte ) ( bandX >> 8 );
		pingbytes[3 ] = ( byte ) ( bandX );
		pingbytes[4 ] = ( byte ) ( 0x02 );
		
		packet.body = pingbytes;
		packet.bodyType = 0x06;
		packet.bodySize = packet.body.length;
		packet.rtmpChannel = 0x02;
		packet.flvChannel = 0;

		return packet;
		
	}
	
	/**
	 * Creates a read message
	 * @param bytesX
	 * @return
	 */
	
	public RTMPPacket readMessage ( int bytesX )
	{
				
		//System.out.println( System.currentTimeMillis( ) + "PacketFactory.readMessage " + bandX );

		RTMPPacket packet;
		
		byte [ ] pingbytes = new byte[4 ];
		pingbytes[0 ] = ( byte ) ( bytesX >> 24 );
		pingbytes[1 ] = ( byte ) ( bytesX >> 16 );
		pingbytes[2 ] = ( byte ) ( bytesX >> 8 );
		pingbytes[3 ] = ( byte ) ( bytesX );
		
		packet = new RTMPPacket( );
		packet.body = pingbytes;
		packet.bodyType = 0x03;
		packet.bodySize = packet.body.length;
		packet.flvChannel = 0;
		packet.rtmpChannel = 0x02;			

		return packet;
		
	}


}
