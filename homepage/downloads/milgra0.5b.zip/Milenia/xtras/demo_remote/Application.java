package application;

import java.util.ArrayList;

import com.milgra.server.Client;
import com.milgra.server.Wrapper;
import com.milgra.server.IApplication;

public class Application implements IApplication
{
	
	public Application ( ) 
	{ 
		System.out.println( System.currentTimeMillis() + " MilGraDemoRemote started" ); 
	}
	
	public void onEnter ( Client clientX , ArrayList < Wrapper > argumentsX ) 
	{ 
		System.out.println( System.currentTimeMillis() + " MilGraDemoRemote.onEnter " + clientX.id + " " + clientX.ip ); 
		new UserController( clientX , this ); 
	}	
	
	public void onLeave ( Client clientX )
	{
		System.out.println( System.currentTimeMillis() + " MilGraDemoRemote.onLeave " + clientX.id + " " + clientX.ip ); 
	}
	
	public void onClose ( ) { }

}
