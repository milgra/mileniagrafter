package application;

import java.util.HashMap;
import java.util.ArrayList;

import com.milgra.server.Client;
import com.milgra.server.Wrapper;
import com.milgra.server.EventListener;
import com.milgra.server.IApplication;


public class UserController 
{
	
	public Client client;
	public Client remoteClient;
	public IApplication main;
	
	/**
	 * UserController constructor
	 * @param clientX
	 */
	
	public UserController ( Client clientX , IApplication mainX )
	{
		
		System.out.println( System.currentTimeMillis() + " UserController.construct " + clientX.ip + " " + clientX.id );
		
		// create stream event listener
		
		EventListener streamEL = new EventListener ( )
		{
			public void onEvent ( HashMap < String , Wrapper > eventX ) { onStream( eventX ); }
		};
		
		// create invoke event listener
		
		EventListener invokeEL = new EventListener ( )
		{
			public void onEvent ( HashMap < String , Wrapper > eventX ) { onInvoke( eventX ); }
		};
		
		main = mainX;
		client = clientX;
		
		// add invoke event listener
		
		client.addInvokeEventListener( invokeEL );
		
		// add stream event listener
		
		client.addStreamEventListener( streamEL );
		
		// accept client
		
		client.accept( new Wrapper( ) );
		
	}
	
	/**
	 * Incoming invoke
	 * @param eventX
	 */
	
	public void onInvoke ( HashMap < String , Wrapper > eventX )
	{
		
		String invokeID = eventX.get( "invokeid" ).stringValue;
		ArrayList < Wrapper > arguments = eventX.get( "arguments" ).listValue; 

		System.out.println( System.currentTimeMillis() + " UserController.onInvoke: " + invokeID );

		if ( invokeID.equals( "connectBack" ) ) connectBack( );
		if ( invokeID.equals( "callRemote" ) ) callRemote( );	
		if ( invokeID.equals( "publishStream" ) ) publishStream( );
		if ( invokeID.equals( "remoteFunction" ) ) remoteFunction( arguments );
		
	}
	
	/**
	 * Stream event
	 * @param eventX
	 */
	
	public void onStream ( HashMap < String , Wrapper > eventX )
	{
		
		String eventID = eventX.get( "eventid" ).stringValue;
		String streamName = eventX.get( "streamname" ).stringValue;
		double streamID = eventX.get( "streamid" ).doubleValue;
		
		System.out.println( System.currentTimeMillis() + " UserController.onStream " + eventID + " " +  streamName +  " " + streamID );
		
		HashMap < Double , String > streams = Client.getStreams( );
		
		if ( eventID.equals( "publish" ) )
		{
			
			// if the stream is called normalstream, and there aren't any more of it, enable
			
			if ( streamName.equals( "normalstream" ) && !streams.containsValue( "normalstream" ) )
			{
				if ( client.id == 0 ) client.enableStreamPublish( streamID , streamName , "live" );
			}
			
			// a remote connection wants to publish "normalstream", we enable it under a new name "remotestream"
			
			else client.enableStreamPublish( streamID , "remotestream" , "live" );
			
		}
		if ( eventID.equals( "play" ) )
		{
			
			// enable play any stream
			
			client.enableStreamPlay( streamID , streamName );
			
		}
		
	}
	
	/**
	 * Connecting remotely to mother application
	 */
	
	public void connectBack ( )
	{
		
		remoteClient = Client.createClient( main );
		
		// create status event listener
		
		EventListener statusEL = new EventListener( )
		{
			public void onEvent ( HashMap < String , Wrapper > eventX ) { onStatus( eventX ); }
		};
		
		// adding event listener
		
		remoteClient.addStatusEventListener( statusEL );
		
		// connecting
		
		remoteClient.connect( "rtmp://localhost/milgrademoremote" , new ArrayList < Wrapper > ( ) );
		
	}
	
	/**
	 * Connection status event
	 * @param eventX
	 */
	
	public void onStatus ( HashMap < String , Wrapper > eventX )
	{
		
		System.out.println( System.currentTimeMillis() + " UserController.onStatus: " );
		
		for ( String key : eventX.keySet() ) System.out.print( key + " " + eventX.get( key ).value + " , ");
		
	}
	
	/**
	 * Call a remote function
	 */
	
	public void callRemote ( )
	{
		
		System.out.println( System.currentTimeMillis() + " UserController.callRemote" );
		
		ArrayList < Wrapper > arguments = new ArrayList < Wrapper > ( );
		arguments.add( new Wrapper( "testargument" ) );
		
		remoteClient.call( "remoteFunction" , arguments );
		
	}
	
	/**
	 * Remote call response, upper function calls this through the remote conneciton
	 * @param argumentsX
	 */
	
	public void remoteFunction ( ArrayList < Wrapper > argumentsX )
	{
		
		System.out.println( System.currentTimeMillis() + " UserController.remoteFunction: " + argumentsX.get( 0 ).stringValue );
		
	}
	
	/**
	 * Publish to remote server ( stream proxy )
	 */
	
	public void publishStream ( )
	{
		
		HashMap < Double , String > publishedStreams = client.getPublishedStreams( );
		
		// searching for "normalstream"'s id
		
		for ( double id : publishedStreams.keySet() )
		{
			
			if ( publishedStreams.get( id ).equals( "normalstream" ) )
			{
				
				System.out.println( "UserController.publishStream" );
				
				// publihs stream on remote connection
				
				remoteClient.publishStream( "normalstream" , "live" );
				
			}
		}
		
	}
	
}
