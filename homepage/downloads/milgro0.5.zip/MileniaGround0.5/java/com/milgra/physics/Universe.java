package com.milgra.physics;

import java.util.ArrayList;

public class Universe 
{
	
	/*
	 * Milenia Ground Engine
	 * 
	 * Copyright (c) 2007 by Milan Toth. All rights reserved.
	 * 
	 * This program is free software; you can redistribute it and/or
	 * modify it under the terms of the GNU General Public License
	 * as published by the Free Software Foundation; either version 2
	 * of the License, or (at your option) any later version.
	 *
	 * This program is distributed in the hope that it will be useful,
	 * but WITHOUT ANY WARRANTY; without even the implied warranty of
	 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	 * GNU General Public License for more details.
	 *
	 * You should have received a copy of the GNU General Public License
	 * along with this program; if not, write to the Free Software
	 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
	 * 
	 */
	
	/**
	 * Universe represents life, universe and everything.
	 * 
	 * @mail milgra@milgra.com
	 * @author Milan Toth
	 * @version 20070821
	 * 
	 */
	
	public Vector force;
	public ArrayList < Point > points;
	public ArrayList < Spacer > spacers;
	public ArrayList < Vector > surfaces;
	
	/**
	 * Universe constructor
	 */
	
	public Universe ( )
	{
		
		force = new Vector( 0 , 0 );
		points = new ArrayList < Point > ( );
		spacers = new ArrayList < Spacer > ( );
		surfaces = new ArrayList < Vector > ( );
		
	}
	
	/**
	 * Adds new masspoint to the simulation
	 * @param pointX
	 */
	
	public void addPoint ( Point pointX ) 
	{ 
		points.add( pointX );	
	}
	
	/**
	 * Adds new spacer to simulation
	 * @param spacerX
	 */
	
	public void addSpacer ( Spacer spacerX ) 
	{ 
		spacers.add( spacerX ); 
	}
	
	/**
	 * Adds new surface point pair to simulation
	 * @param pointAX
	 * @param pointBX
	 */
	
	public void addSurfaces ( Vector pointAX , Vector pointBX ) 
	{ 
		surfaces.add( pointAX ); surfaces.add( pointBX ); 
	}
	
	/**
	 * Steps in simulation
	 */
	
	public void step ( )
	{
		
		for ( Point point : points ) point.reforce( this );
		for ( Spacer spacer : spacers ) spacer.respace( this );			
		
	}
	
	/**
	 * Checks collosion with surface vectors
	 * @param vectorAX start point of colliding vector
	 * @param vectorBX end point of colliding vecotr
	 * @return Vector array, first element is the collosion point, second and third is the collosion vector
	 */

	public Vector [ ] collide ( Vector vectorAX ,
						  		Vector vectorBX )
	{

		int a;
		boolean box;
		
		Vector hit;
		Vector vectorCX;
		Vector vectorDX;
		
		for ( a = 0 ; a < surfaces.size( ) - 1 ; a++ )
		{
			
			vectorCX = surfaces.get(a);
			vectorDX = surfaces.get(a+1);
	
			box = Vector.checkBounds( vectorAX , 
									  vectorBX , 
									  vectorCX ,
									  vectorDX );
			
			if ( box )
			{
				
				hit = Vector.collide( vectorAX , 
									  vectorBX , 
									  vectorCX , 
									  vectorDX );
				
				if ( hit != null ) return new Vector [ ] { hit , 
														   vectorCX , 
														   vectorDX };
				
			}
			
		}
		
		return null;	
		
	}

}
