package com.milgra.physics;

public class Vector 
{
	
	/*
	 * Milenia Ground Engine
	 * 
	 * Copyright (c) 2007 by Milan Toth. All rights reserved.
	 * 
	 * This program is free software; you can redistribute it and/or
	 * modify it under the terms of the GNU General Public License
	 * as published by the Free Software Foundation; either version 2
	 * of the License, or (at your option) any later version.
	 *
	 * This program is distributed in the hope that it will be useful,
	 * but WITHOUT ANY WARRANTY; without even the implied warranty of
	 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	 * GNU General Public License for more details.
	 *
	 * You should have received a copy of the GNU General Public License
	 * along with this program; if not, write to the Free Software
	 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
	 * 
	 */
	
	/**
	 * Vector represents a base vector
	 * 
	 * @mail milgra@milgra.com
	 * @author Milan Toth
	 * @version 20070821
	 * 
	 */
	
	public double x;
	public double y;
	
	/**
	 * Vector constructor
	 * @param pointXX
	 * @param pointYX
	 */
	
	public Vector ( double pointXX ,
					double pointYX )
	{
		
		x = pointXX;
		y = pointYX;
		
	}
	
	/**
	 * Calculates center point of two vectors
	 * @param vectorAX
	 * @param vectorBX
	 * @return
	 */
	
	public static Vector center ( Vector vectorAX , 
								  Vector vectorBX )
	{
		
		return new Vector( vectorAX.x + ( vectorBX.x - vectorAX.x ) / 2 , 
						   vectorAX.y + ( vectorBX.y - vectorAX.y ) / 2 );
		
	}
	
	/**
	 * Calculates vector length
	 * @param vectorX
	 * @return
	 */
	
	public static double length ( Vector vectorX )
	{
		
		return Math.sqrt( vectorX.x * vectorX.x + vectorX.y * vectorX.y );
		
	}
	
	/**
	 * Adds two vectors
	 * @param vectorAX
	 * @param vectorBX
	 * @return
	 */
	
	public static Vector add ( Vector vectorAX ,
							   Vector vectorBX )
	{
		
		return new Vector( vectorAX.x + vectorBX.x , vectorAX.y + vectorBX.y );
		
	}
	
	/**
	 * Resizes a vector
	 * @param vectorX
	 * @param lengthX
	 * @return
	 */
	
	public static Vector resize ( Vector vectorX ,
								  double lengthX )
	{
		
		double length = Vector.length( vectorX );
		double ratio = lengthX / length;
		
		return new Vector( vectorX.x * ratio , vectorX.y * ratio );
		
	}
	
	/**
	 * Increases vector with given amount
	 * @param vectorX
	 * @param amountX
	 * @return
	 */
	
	public static Vector increase ( Vector vectorX ,
									double amountX )
	{
		
		double length = Vector.length( vectorX );
		double ratio = ( length + amountX ) / length;
		
		return new Vector( vectorX.x * ratio , vectorX.y * ratio );
		
	}
	
	/**
	 * Checks bounding box intersection
	 * @param vectorAX
	 * @param vectorBX
	 * @param vectorCX
	 * @param vectorDX
	 * @return boolean, true if collides
	 */
	
	public static boolean checkBounds ( Vector vectorAX ,
										Vector vectorBX ,
										Vector vectorCX , 
										Vector vectorDX )
	{
		
		double rxA = ( vectorBX.x - vectorAX.x ) / 2;
		double ryA = ( vectorBX.y - vectorAX.y ) / 2;
		double rxB = ( vectorDX.x - vectorCX.x ) / 2;
		double ryB = ( vectorDX.y - vectorCX.y ) / 2;
		
		double dx = Math.abs ( ( vectorCX.x + rxB ) - ( vectorAX.x + rxA ) );
		double dy = Math.abs ( ( vectorCX.y + ryB ) - ( vectorAX.y + ryA ) );
		
		if ( dx <= ( Math.abs( rxA ) + Math.abs( rxB ) ) && 
			 dy <= ( Math.abs( ryA ) + Math.abs( ryB ) ) ) return true;
		
		return false;
		
	}
	
	/**
	 * Checks vector collosion
	 * @param vectorAX
	 * @param vectorBX
	 * @param vectorCX
	 * @param vectorDX
	 * @return intersection point or null
	 */
	
	public static Vector collide ( Vector vectorAX ,
								   Vector vectorBX ,
								   Vector vectorCX ,
								   Vector vectorDX )
	{
		
		Line   lineA = new Line( vectorAX , vectorBX );
		Line   lineB = new Line( vectorCX , vectorDX );
		Vector cross = Line.intersect( lineA , lineB );
		
		if ( cross != null )
		{
	
			Vector vA = new Vector( vectorBX.x - vectorAX.x , vectorBX.y - vectorAX.y );
			Vector vB = new Vector( vectorDX.x - vectorCX.x , vectorDX.y - vectorCX.y );
		
			Vector cA = Vector.center( vectorAX , vectorBX );
			Vector cB = Vector.center( vectorCX , vectorDX );
			
			Vector dA = new Vector( cA.x - cross.x , cA.y - cross.y );
			Vector dB = new Vector( cB.x - cross.x , cB.y - cross.y );
			
			// if distances from center points are bigger than radius of second vector, there is no collosion
			
			if ( 4 * ( dA.x * dA.x + dA.y * dA.y ) > ( vA.x * vA.x + vA.y * vA.y ) ) return null;  
			if ( 4 * ( dB.x * dB.x + dB.y * dB.y ) > ( vB.x * vB.x + vB.y * vB.y ) ) return null;  
			
			return cross;
		
		} else return null;		
		
	}
	
	/**
	 * Reflects a vector on another vector
	 * @param vectorAX
	 * @param vectorBX
	 * @param vectorCX
	 * @param vectorDX
	 * @return reflected vector
	 */
	
	public static Vector reflect ( Vector vectorAX ,
								   Vector vectorBX ,
								   Vector vectorCX ,
								   Vector vectorDX )
	{
		
		Line line = new Line( vectorCX , vectorDX );
		Line normal = Line.normal( line );
		
		Line lineA = Line.translate( normal , vectorAX );
		Line lineB = Line.translate( normal , vectorBX );
		
		Vector crossA = Line.intersect( lineA , line );
		Vector crossB = Line.intersect( lineB , line );
		
		double x1 = vectorAX.x + ( crossA.x - vectorAX.x ) * 2; 
		double y1 = vectorAX.y + ( crossA.y - vectorAX.y ) * 2; 
	
		double x2 = vectorBX.x + ( crossB.x - vectorBX.x ) * 2; 
		double y2 = vectorBX.y + ( crossB.y - vectorBX.y ) * 2; 
	
		return new Vector( x2 - x1 , y2 - y1 );
		
	}

}
