package com.milgra.physics;

public class Spacer 
{
	
	/*
	 * Milenia Ground Engine
	 * 
	 * Copyright (c) 2007 by Milan Toth. All rights reserved.
	 * 
	 * This program is free software; you can redistribute it and/or
	 * modify it under the terms of the GNU General Public License
	 * as published by the Free Software Foundation; either version 2
	 * of the License, or (at your option) any later version.
	 *
	 * This program is distributed in the hope that it will be useful,
	 * but WITHOUT ANY WARRANTY; without even the implied warranty of
	 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	 * GNU General Public License for more details.
	 *
	 * You should have received a copy of the GNU General Public License
	 * along with this program; if not, write to the Free Software
	 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
	 * 
	 */
	
	/**
	 * Spacer keeps the starting space between two points
	 * 
	 * @mail milgra@milgra.com
	 * @author Milan Toth
	 * @version 20070821
	 * 
	 */
	
	public double length;
	public Point pointA;
	public Point pointB;
	
	/**
	 * Respacer constructor
	 * @param pointAX
	 * @param pointBX
	 */
	
	public Spacer ( Point pointAX ,
					Point pointBX )
	{
		
		pointA = pointAX;
		pointB = pointBX;
		
		Vector vector = new Vector( pointBX.position.x - pointAX.position.x , 
									pointBX.position.y - pointAX.position.y );
		
		length = Vector.length( vector );
		
	}
	
	/**
	 * Respaces masspoints
	 * @param universeX
	 */
	
	public void respace ( Universe universeX )
	{
		
		Vector distanceA = new Vector( pointB.position.x - pointA.position.x , pointB.position.y - pointA.position.y );
		Vector distanceB = new Vector( pointA.position.x - pointB.position.x , pointA.position.y - pointB.position.y );
	
		double delta = ( Vector.length( distanceA ) - length ) / 2;
		
		Vector respacerA = Vector.resize( distanceA , delta );
		Vector respacerB = Vector.resize( distanceB , delta );
		
		collide( pointA , respacerA , universeX );
		collide( pointB , respacerB , universeX );
		
		pointA.movement = Vector.add( pointA.movement , respacerA );
		pointB.movement = Vector.add( pointB.movement , respacerB );
		
		if ( pointA.collided ) pointB.movement = Vector.add( pointB.movement , respacerB );
		if ( pointB.collided ) pointA.movement = Vector.add( pointA.movement , respacerA );
			
	}
	
	/**
	 * Collides respacer
	 * @param pointX
	 * @param respacerX
	 * @param universeX
	 */
	
	public void collide ( Point pointX ,
						  Vector respacerX ,
						  Universe universeX )
	{
		
		Vector helper = Vector.increase( respacerX , 1 );
		Vector ending = Vector.add( pointX.position , helper );
		
		Vector [ ] collosion = universeX.collide( pointX.position , ending );
		
		if ( collosion == null ) 
		{
			pointX.position = Vector.add( pointX.position , respacerX );
		}
		else 
		{
			pointX.position = Vector.add( collosion[0] , Vector.resize( helper , -1 ) );
		}
			
	}

}
