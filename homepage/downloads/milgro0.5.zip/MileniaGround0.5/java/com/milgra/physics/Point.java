package com.milgra.physics;

public class Point 
{
	
	/*
	 * Milenia Ground Engine
	 * 
	 * Copyright (c) 2007 by Milan Toth. All rights reserved.
	 * 
	 * This program is free software; you can redistribute it and/or
	 * modify it under the terms of the GNU General Public License
	 * as published by the Free Software Foundation; either version 2
	 * of the License, or (at your option) any later version.
	 *
	 * This program is distributed in the hope that it will be useful,
	 * but WITHOUT ANY WARRANTY; without even the implied warranty of
	 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	 * GNU General Public License for more details.
	 *
	 * You should have received a copy of the GNU General Public License
	 * along with this program; if not, write to the Free Software
	 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
	 * 
	 */
	
	/**
	 * Point represents a mass point with rigidity and movement vector
	 * 
	 * @mail milgra@milgra.com
	 * @author Milan Toth
	 * @version 20070821
	 * 
	 */
	
	public double rigidity;
	public boolean collided;
	
	public Vector position;
	public Vector movement;
	
	/**
	 * Point constructor
	 * @param vectorX
	 * @param rigidityX
	 */
	
	public Point ( Vector vectorX ,
				   double rigidityX )
	{
		
		rigidity = rigidityX;
		movement = new Vector( 0 , 0 );
		position = new Vector( vectorX.x , vectorX.y );
		
	}
	
	/**
	 * Reforces masspoint
	 * @param universeX
	 */
	
	public void reforce ( Universe universeX )
	{
		
		collided = false;
		movement = Vector.add( movement , universeX.force );			
		
		Vector helper = Vector.increase( movement , .5 );
		Vector ending = Vector.add( position , helper );
		Vector [ ] collosion = universeX.collide( position , ending );
		
		if ( collosion != null )
		{
								
				collided = true;
				movement = Vector.reflect( position , ending , collosion[1] , collosion[2] );
			 	movement = Vector.resize( movement , Vector.length( movement ) * rigidity );
				position = Vector.add( collosion[0] , Vector.resize( helper , -.5 ) );
							
		} 
		else position = Vector.add( position , movement );
		
	}

}
