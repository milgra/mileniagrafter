package com.milgra.physics;

public class Line 
{
	
	/*
	 * Milenia Ground Engine
	 * 
	 * Copyright (c) 2007 by Milan Toth. All rights reserved.
	 * 
	 * This program is free software; you can redistribute it and/or
	 * modify it under the terms of the GNU General Public License
	 * as published by the Free Software Foundation; either version 2
	 * of the License, or (at your option) any later version.
	 *
	 * This program is distributed in the hope that it will be useful,
	 * but WITHOUT ANY WARRANTY; without even the implied warranty of
	 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	 * GNU General Public License for more details.
	 *
	 * You should have received a copy of the GNU General Public License
	 * along with this program; if not, write to the Free Software
	 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
	 * 
	 */
	
	/**
	 * Line represents a line in slope - intercept form
	 * 
	 * @mail milgra@milgra.com
	 * @author Milan Toth
	 * @version 20070821
	 * 
	 */
	
	public double m;
	public double b;
	
	/**
	 * Line constructor
	 * @param vectorAX
	 * @param vectorBX
	 */
	
	public Line ( Vector vectorAX ,
				  Vector vectorBX )
	{
		
		double dx = vectorBX.x - vectorAX.x;
		double dy = vectorBX.y - vectorAX.y;
		
		if ( dx == 0 )
		{
			
			// line is vertical
	
			m = Double.POSITIVE_INFINITY;
			b = vectorAX.x;
			
		}
		else
		if ( dy == 0 )
		{
			
			// line is horizontal
			
			m = 0;
			b = vectorAX.y;
			
		}
		else
		{
		
			m = dy / dx;
			b = vectorAX.y - m * vectorAX.x;
			
		}
		
	}
	
	/**
	 * Calculates intersection point of two lines based on slope-intercept form
	 * @param lineAX
	 * @param lineBX
	 * @return
	 */
	
	public static Vector intersect ( Line lineAX ,
									 Line lineBX )
	{
		
		if ( lineAX.m != lineBX.m )
		{
			
			Vector result = new Vector( 0 , 0 );
			
			if ( !Double.isInfinite( lineAX.m ) && !Double.isInfinite( lineBX.m ) )
			{
				
				// normal lines

				result.x = ( lineBX.b - lineAX.b ) / ( lineAX.m - lineBX.m );
				result.y = ( lineBX.m * result.x ) + lineBX.b;
				
			}
			else if ( Double.isInfinite( lineAX.m ) && !Double.isInfinite( lineBX.m ) )
			{
				
				// lineAX is vertical
				
				result.x = lineAX.b;
				result.y = lineAX.b * lineBX.m + lineBX.b;

			}
			else if ( !Double.isInfinite( lineAX.m ) && Double.isInfinite( lineBX.m ) )
			{
				
				// lineBX is vertical
				
				result.x = lineBX.b;
				result.y = lineBX.b * lineAX.m + lineAX.b;
				
			}
			
			return result;
			
		}
		else return null;
		
	}
	
	/**
	 * Creates a normal line to the given line
	 * @param lineX
	 * @return
	 */
	
	public static Line normal ( Line lineX )
	{
		
		Line result = new Line( new Vector( 0 , 0 ) , new Vector( 0 , 0 ) );
	
		if ( Double.isInfinite( lineX.m ) )
		{
			
			// vertical line
			
			result.m = 0;
			result.b = lineX.b;
			
		}
		else
		if ( lineX.m == 0 )
		{
			
			// horizontal line
			
			result.m = Double.POSITIVE_INFINITY;
			result.b = lineX.b;
			
		}
		else
		{
			
			// normal line
	
			result.m = -1 / lineX.m;
			result.b = lineX.b;
			
		}
			
		return result;
		
	}
	
	/**
	 * Translates ( displaces ) the given line to the given point
	 * @param lineX
	 * @param vectorX
	 * @return
	 */
	
	public static Line translate ( Line lineX ,
								 Vector vectorX )
	{
		
		Line result = new Line( new Vector( 0 , 0 ) , new Vector( 0 , 0 ) );
	
		if ( Double.isInfinite( lineX.m ) )	
		{
		
			// vertical line
			
			result.b = vectorX.x;
		
		} 
		else
		if ( lineX.m == 0 )	
		{
			
			// horizontal line
		
			result.b = vectorX.y;
		
		} 
		else 
		{
			
			// normal line
		
			result.b = vectorX.y - lineX.m * vectorX.x;
		
		}
		
		result.m = lineX.m;
		
		return result;
		
	}

}