package application.modules;

import com.milgra.server.api.Client;
import com.milgra.server.api.WrapperList;

public class SSRecord 
{

	
	/**
	 * Closes module
	 **/
	
	public void onEnter ( Client clientX , WrapperList argumentsX ) 
	{
		
		System.out.println( System.currentTimeMillis( ) +  " SSRecord.onClose " );
		
		
	}
	/**
	 * Closes module
	 **/
	
	public void onLeave ( Client clientX ) 
	{
		
		System.out.println( System.currentTimeMillis( ) +  " SSRecord.onClose " );
		
		
	}
}
